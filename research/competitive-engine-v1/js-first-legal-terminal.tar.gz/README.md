# First-legal terminal check: failed efficiency gate

The prototype passed 174 portable cases, checked first-legal existence on 142 rule snapshots and 2,044 legal successors, and passed 55 targeted tests. The first targeted invocation lacked fixture dependencies; both logs are included. All 32 fixed-depth roots completed in every arm with identical actions, scores, nodes, PVs and depths. The baseline took 757.647 ms in aggregate; the prototype took 765.852 ms (1.08% slower; gate required 5% faster). At 100 ms both averaged 6.3125 completed plies. No retry, match, or production change follows.

To reproduce, run `node preflight.mjs`, `node --test test/*.test.js`, and `node timing.mjs` from this directory. The recorded timings come from one ABBA comparison under each budget.
