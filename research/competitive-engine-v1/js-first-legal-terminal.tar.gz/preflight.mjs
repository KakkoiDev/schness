import assert from 'node:assert/strict';
import {contractRequests,assertContract} from './scripts/engine-contract.js';
import {executeContract} from './scripts/engine-contract-js.js';
import * as r from './candidate/rules.js';
import * as b from './baseline/rules.js';
import {analyzeAction as control} from './baseline/bot.js';
import {analyzeAction as candidate} from './candidate/bot.js';
let rules=0, successors=0, contracts=0;
for (const request of contractRequests()){
  assertContract(request,executeContract({...request,options:{...request.options,firstLegalTerminal:true}}));contracts++;
  const {state:p,options,game}=request;
  if(game==='schness-rules-v1'){
    const legal=b.legalActions(p);rules++;
    assert.equal(r.hasLegalActionUnchecked(p),legal.length>0,request.id);
    for(const action of legal){
      const q=b.applyAction(p,action);
      assert.equal(r.hasLegalActionUnchecked(q),b.legalActions(q).length>0,request.id);successors++;
    }
  }
  if(game==='schness-v1'||game==='schness-rules-v1'){
    const snapshot=JSON.stringify(p);
    for(const opts of [options??{profile:'competitive',depth:2,maxNodes:1000},{profile:'competitive',depth:4,maxNodes:64}]){
      const a=control(p,opts),c=candidate(p,{...opts,firstLegalTerminal:true});
      for(const key of ['action','score','completedDepth','nodes','stopped','pv','variations']) assert.deepEqual(c[key],a[key],request.id+': '+key);
      assert.equal(JSON.stringify(p),snapshot,request.id);
    }
  }
}
console.log(JSON.stringify({contracts,rules,successors}));
