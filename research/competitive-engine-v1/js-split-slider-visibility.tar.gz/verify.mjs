import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import * as r from './control/rules.js';
const read=p=>JSON.parse(readFileSync(p,'utf8'));
const {paths}=read('inputs.json'),sum=read('summary.json');
const rows=readFileSync('timing.jsonl','utf8').trim().split('\n').map(x=>JSON.parse(x));
assert.equal(rows.length,256);
const geometry=read('geometry.json');
assert.deepEqual(geometry,Array.from({length:16},(_,square)=>({square,comparisons:65536})));
let rng=20264037;
for(const [id,path] of paths.entries()){
 assert.equal(path.id,id);assert.equal(path.before,rng);
 let p=r.createInitialPosition({experiment:'capture-bank',allowCheckingDrops:false,bankCapacity:6});
 for(const move of path.transcript){
  const legal=r.legalActions(p).sort((a,b)=>r.actionKey(a)<r.actionKey(b)?-1:r.actionKey(a)>r.actionKey(b)?1:0);
  rng=(Math.imul(rng,1664525)+1013904223)>>>0;
  assert.deepEqual(move,legal[Math.floor(rng*legal.length/2**32)]);
  p=r.applyAction(p,move);
 }
 assert.equal(path.after,rng);assert.deepEqual(path.p,p);assert.deepEqual(path.terminal,r.getResult(p));
}
for(const [idx,row] of rows.entries()){
 assert.equal(row.id,idx%32);assert.equal(row.pass,Math.floor(idx/32)%4);
 assert.equal(row.phase,idx<128?'fixed':'timed');assert(Number.isFinite(row.ms)&&row.ms>=0);
 if(idx<128)assert.deepEqual(row.result,rows[row.id].result);
 for(const pv of [row.result.pv,...row.result.variations.map(x=>x.pv)]){
  let p=paths[row.id].p;
  for(const move of pv)p=r.applyAction(p,move);
 }
}
for(const [i,phase] of ['fixed','timed'].entries())for(let pass=0;pass<4;pass++){
 const block=rows.slice(i*128+pass*32,i*128+(pass+1)*32);
 assert.equal(sum[phase][pass].ms,block.reduce((a,b)=>a+b.ms,0));
 assert.equal(sum[phase][pass].meanDepth,block.reduce((a,b)=>a+b.result.completedDepth,0)/32);
}
console.log('Verified 32 fresh paths, 256 timed records, complete fixed-depth parity and every reported continuation.');
