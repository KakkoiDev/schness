#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
test ! -e timing.jsonl
printf 'active\n' > state.txt
trap 'status=$?; if [ "$status" = 0 ]; then printf "inactive: completed\n" > state.txt; else printf "inactive: failed (%s)\n" "$status" > state.txt; fi' EXIT
shasum -a 256 PLAN.md run.mjs launch.sh resume.sh control/*.js candidate/*.js portable/* rule-fixtures.json timed-settings.json > FINAL-SOURCE-SHA256SUMS
node --test portable/*test.js > mates.log 2>&1
node run.mjs timing > timing.log 2>&1
shasum -a 256 -c FINAL-SOURCE-SHA256SUMS > verification.log
test "$(wc -l < timing.jsonl | tr -d ' ')" = 256
