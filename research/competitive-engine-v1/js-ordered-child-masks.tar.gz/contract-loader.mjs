export async function resolve(specifier,context,next){
 if(specifier==='../src/bot.js' && context.parentURL?.endsWith('/scripts/engine-contract-js.js')){
   return next(new URL('./candidate/bot.js',import.meta.url).href,context);
 }
 return next(specifier,context);
}
