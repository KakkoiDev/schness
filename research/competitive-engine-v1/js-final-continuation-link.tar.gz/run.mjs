import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,appendFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import * as r from './control/rules.js';
import {analyzeAction as control} from './control/bot.js';
import {analyzeAction as candidate} from './candidate/bot.js';
const read=p=>JSON.parse(readFileSync(p,'utf8'));
const save=(p,x)=>writeFileSync(p,JSON.stringify(x,null,2)+'\n');
const add=(p,x)=>appendFileSync(p,JSON.stringify(x)+'\n');
const rules={experiment:'capture-bank',allowCheckingDrops:false,bankCapacity:6};
let rng=20264277;
const paths=Array.from({length:32},(_,id)=>{
  let p=r.createInitialPosition(rules);
  const before=rng,target=[8,16,24,32][id%4],transcript=[];
  while(transcript.length<target&&!r.getResult(p)){
    const a=r.legalActions(p).sort((x,y)=>r.actionKey(x)<r.actionKey(y)?-1:r.actionKey(x)>r.actionKey(y)?1:0);
    rng=(Math.imul(1664525,rng)+1013904223)>>>0;
    const move=a[Math.floor(rng*a.length/2**32)];transcript.push(move);p=r.applyAction(p,move);
  }
  return {id,before,after:rng,target,transcript,p,terminal:r.getResult(p)};
});
const {depthRequest,...settings}=read('timed-settings.json');
const timed={...settings,depth:depthRequest,maxMillis:100};
const fixed={...timed,depth:4,maxNodes:100000,maxMillis:200,lateMoveReduction:false,stopOnProvenWin:false};
save('inputs.json',{fixed,timed,paths});
function query(fn,p,opts){
  const copy=structuredClone(p),t=performance.now(),result=fn(p,opts),ms=performance.now()-t;
  assert.deepEqual(p,copy);
  for(const line of [{pv:result.pv},...result.variations]){
    let next=p;
    for(const a of line.pv)next=r.applyAction(next,a);
  }
  return {result,ms};
}
if(process.argv[2]==='timing'){
  const arms=[control,candidate,candidate,control];
  const results={};
  for(const [phase,opts] of [['fixed',fixed],['timed',timed]]){
    const passes=[];
    for(const [pass,fn] of arms.entries()){
      const rows=paths.map(x=>query(fn,x.p,opts));
      for(const [id,q] of rows.entries())add('timing.jsonl',{phase,pass,id,...q});
      passes.push(rows);
    }
    if(phase==='fixed')for(const [id,path] of paths.entries())for(const rows of passes){
      assert(path.terminal||rows[id].result.completedDepth===4);
      assert.deepEqual(rows[id].result,passes[0][id].result);
    }
    results[phase]=passes.map(rows=>({ms:rows.reduce((a,b)=>a+b.ms,0),meanDepth:rows.reduce((a,b)=>a+b.result.completedDepth,0)/32}));
  }
  const [a,b,c,d]=results.fixed.map(x=>x.ms),[e,f,g,h]=results.timed.map(x=>x.meanDepth);
  results.savings=1-(b+c)/(a+d);results.depthDelta=(f+g-e-h)/2;
  results.passed=results.savings>=.05&&results.depthDelta>=0;
  save('summary.json',results);console.log(results);
}else throw Error('Pass timing');
