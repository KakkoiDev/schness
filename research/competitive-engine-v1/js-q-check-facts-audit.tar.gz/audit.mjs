import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import * as r from './baseline/rules.js';
import {analyzeAction as a} from './baseline/bot.js';
function edit(name,from,to){
 const path=new URL('./instrumented/'+name,import.meta.url),code=readFileSync(path,'utf8');
 assert.equal(code.split(from).length,2,from);writeFileSync(path,code.replace(from,to));
}
edit('search.js','const danger = Boolean(adapter.inDanger?.(p)) || Boolean(ctx.options.forkThreatEvasions &&',`const checked=Boolean(adapter.inDanger?.(p));
      facts.observedCheck=checked;
      ctx.options.onCheckAudit("danger",checked);
      const danger = checked || Boolean(ctx.options.forkThreatEvasions &&`);
edit('bot.js',`if (masksInCheck(masks, enemy)) score += 30;
  if (masksInCheck(masks, player)) score -= 30;`,`const enemyCheck=masksInCheck(masks, enemy);
  if(enemyCheck)score+=30;
  const playerCheck=masksInCheck(masks, player);
  if(playerCheck)score-=30;
  facts.options.onCheckAudit("evaluation",facts.observedCheck,position.turn===player?playerCheck:enemyCheck);`);
const {analyzeAction:b}=await import('./instrumented/bot.js');
const rules={allowCheckingDrops:false,experiment:'capture-bank',bankCapacity:6};
const initialSeed=20263421;
let seed=initialSeed;
const random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
const cases=[];
for(let id=0;id<32;id++){
 const target=[8,16,24,32][id%4],transcript=[];
 let p=r.createInitialPosition(rules);
 for(let i=0;i<target&&!r.getResult(p);i++){
  const legal=r.legalActions(p).sort((a,b)=>r.actionKey(a)<r.actionKey(b)?-1:1),action=legal[Math.floor(random()*legal.length)];
  transcript.push(action);p=r.applyAction(p,action);
 }
 cases.push({id,target,position:p,transcript,result:r.getResult(p)});
}
const options={profile:'competitive',depth:4,iterativeDeepening:true,maxMillis:200,maxNodes:100000,quiescenceDepth:4,quiescenceChecks:true,quiescenceEvasionDepth:2,lateMoveReduction:false,cacheEvaluation:true,cacheQuiescence:false,reducePrincipalVariation:true,reduceQuietDrops:false,stopOnProvenWin:false};
const rows=[],errors=[];
for(const {id,position:p,result:terminal} of cases){
 const queries={},counts={danger:0,evaluation:0,repeatable:0};const mismatches=[];
 for(const arm of ['control','instrumented']){
  const snapshot=JSON.stringify(p),t=performance.now();
  const onCheckAudit=(kind,observed,current)=>{
   if(kind==='danger'){counts.danger++;return;}
   counts.evaluation+=2;
   if(observed!==undefined){
    counts.repeatable++;
    if(observed!==current){mismatches.push({observed,current});errors.push({id,observed,current});}
   }
  };
  const result=(arm==='control'?a:b)(p,{...options,...(arm==='instrumented'?{onCheckAudit}:{})});
  queries[arm]={elapsed:performance.now()-t,result};
  assert.equal(JSON.stringify(p),snapshot);
  if(terminal)assert.equal(result.action,null);
  else{
   r.applyAction(p,result.action);
   if(result.pv.length)assert.deepEqual(result.pv[0],result.action);
   let next=p;for(const action of result.pv)next=r.applyAction(next,action);
  }
 }
 const left=queries.control.result,right=queries.instrumented.result;
 const complete=terminal||[left,right].every(x=>x.completedDepth===4&&!x.stopped);
 if(complete)for(const key of ['action','score','pv','nodes','completedDepth'])
  if(JSON.stringify(left[key])!==JSON.stringify(right[key]))errors.push({id,field:key});
 rows.push({id,complete:!!complete,queries,counts,mismatches});
}
const complete=rows.filter(r=>r.complete);
const calls=complete.reduce((n,r)=>n+r.counts.danger+r.counts.evaluation,0),repeatable=complete.reduce((n,r)=>n+r.counts.repeatable,0),roots=complete.filter(r=>r.counts.repeatable>0).length;
const summary={complete:complete.length,calls,repeatable,roots,fraction:calls?repeatable/calls:0,terminal:cases.filter(c=>c.result).length,errors:errors.length,pass:complete.length>=28&&!errors.length&&repeatable>=0.15*calls&&roots>=8};
writeFileSync(new URL('./results.json',import.meta.url),JSON.stringify({initialSeed,finalSeed:seed,rules,options,cases,rows,errors,summary}));
console.log(JSON.stringify(summary));
