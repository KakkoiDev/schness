import assert from 'node:assert/strict';
import {writeFile,appendFile} from 'node:fs/promises';
import {performance} from 'node:perf_hooks';
import * as r from './control/rules.js';
import {analyzeAction as control} from './control/bot.js';
import {analyzeAction as observed} from './observed/bot.js';
let rng=20263523;
const rules={experiment:'capture-bank',allowCheckingDrops:false,bankCapacity:6};
const base={profile:'competitive',iterativeDeepening:true,maxNodes:100000,maxMillis:200,
  quiescenceDepth:4,quiescenceChecks:true,quiescenceEvasionDepth:2,lateMoveReduction:false,
  cacheEvaluation:true,cacheQuiescence:false,reducePrincipalVariation:true,stopOnProvenWin:false};
const options={...base,depth:3};
const json=x=>JSON.stringify(x,null,2)+'\n';
const paths=Array.from({length:32},(_,id)=>{
  const before=rng, target=[8,16,24,32][id%4],transcript=[];
  let p=r.createInitialPosition(rules);
  while(transcript.length<target && !r.getResult(p)){
    const actions=r.legalActions(p).sort((a,b)=>r.actionKey(a)<r.actionKey(b)?-1:r.actionKey(a)>r.actionKey(b)?1:0);
    rng=(Math.imul(1664525,rng)+1013904223)>>>0;
    const action=actions[Math.floor(rng*actions.length/2**32)];
    transcript.push(action);
    p=r.applyAction(p,action);
  }
  return {id,before,after:rng,target,transcript,p,terminal:r.getResult(p)};
});
await writeFile('inputs.json',json({base,paths}));
const summarize=({action,score,pv,completedDepth,nodes})=>({action,score,pv,completedDepth,nodes});
function query(fn,p,opt){
  const snapshot=structuredClone(p),t=performance.now(), result=fn(p,opt);
  const ms=performance.now()-t;
  assert.deepEqual(p,snapshot);
  for(const line of [{pv:result.pv},...result.variations]){
    let next=p;
    for(const a of line.pv)next=r.applyAction(next,a);
  }
  return {result,ms};
}
const rows=[];
const kind=(p,a)=>a.type==='drop'?'drop':p.board[a.to]?'capture':'quiet';
for(const path of paths){
  let sample;
  const a=query(control,path.p,options);
  const b=query(observed,path.p,{...options,observeInterior:(p,order)=>{
    if(!sample)sample={position:structuredClone(p),order:structuredClone(order),checked:r.isInCheck(p,p.turn)};
  }});
  const complete=Boolean(path.terminal || (a.result.completedDepth===3 && b.result.completedDepth===3));
  const parity=JSON.stringify(summarize(a.result))===JSON.stringify(summarize(b.result));
  const row={id:path.id,a,b,complete,parity,sample};
  if(sample){
    const {position,order}=sample;
    assert.deepEqual(order.map(r.actionKey).sort(),r.legalActions(position).map(r.actionKey).sort());
    sample.classes=order.map(x=>kind(position,x));
    row.labels=[3,4].map(depth=>query(control,position,{...base,depth,multiPv:2,repetitionAversion:false}));
    const [x,y]=row.labels.map(l=>l.result);
    if(x.completedDepth===3 && y.completedDepth===4 && x.variations.length===2 && y.variations.length===2 &&
      x.variations[0].score>x.variations[1].score && y.variations[0].score>y.variations[1].score &&
      r.actionKey(x.action)===r.actionKey(y.action)){
      const index=order.findIndex(a=>r.actionKey(a)===r.actionKey(x.action));
      assert(index>=0);
      row.stable={rank:index+1,kind:sample.classes[index],withinQuiet:sample.classes[index]==='quiet'?sample.classes.slice(0,index+1).filter(x=>x==='quiet').length:null};
    }
  }
  rows.push(row);
  await appendFile('rows.jsonl',JSON.stringify(row)+'\n');
}
const eligible=rows.filter(r=>r.complete), stable=rows.filter(r=>r.stable), late=stable.filter(r=>r.stable.rank>=4);
const summary={roots:rows.length,complete:eligible.length,mismatches:eligible.filter(r=>!r.parity).map(r=>r.id),
  samples:rows.filter(r=>r.sample).length,stable:stable.length,late:late.length,
  passed:eligible.length>=28 && eligible.every(r=>r.parity) && stable.length>=20 && late.length>=8 && late.length/stable.length>=.25};
await writeFile('summary.json',json(summary));
console.log(summary);
