import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import * as r from './baseline/rules.js';
import {analyzeAction as a} from './baseline/bot.js';
const path=new URL('./instrumented/search.js',import.meta.url);
let code=readFileSync(path,'utf8');
function edit(a,b){assert.equal(code.split(a).length,2,a);code=code.replace(a,b);}
edit('  function enter(ctx, tactical) {',`  function observeSibling(ctx,eligible,fn){
    if(!eligible)return fn();
    const previous=ctx.mateTail;
    ctx.mateTail=true;
    try{return fn();}finally{ctx.mateTail=previous;}
  }
  function enter(ctx, tactical) {`);
edit('ctx.nodes++;','ctx.nodes++;if(ctx.mateTail)ctx.options.onMateAudit("tail");');
edit('if(ctx.evalCache)boundedSet(ctx.evalCache,evalKey,standPat,ctx);',
  'if(Math.abs(standPat)>=1000000)ctx.options.onMateAudit("static",standPat);if(ctx.evalCache)boundedSet(ctx.evalCache,evalKey,standPat,ctx);');
edit('const child = withChild(p,action,ctx,next=>visit(next, 0, alpha,beta,player,ctx,Math.max(0,remainingQ-1),remainingQ ? remainingEvasions : remainingEvasions-1));',
  `const limit=maximizing?1000000:-1000000;
        const child = observeSibling(ctx,best.value===limit,()=>withChild(p,action,ctx,next=>visit(next, 0, alpha,beta,player,ctx,Math.max(0,remainingQ-1),remainingQ ? remainingEvasions : remainingEvasions-1)));
        if(Math.abs(child.value)>1000000)ctx.options.onMateAudit("bound",child.value,0);
        if(child.value===limit && best.value!==limit)ctx.options.onMateAudit("attained","q");`);
edit('const child = withChild(p,action,ctx,next=>{',`const cap=1000000+Math.max(0,depth-1),limit=maximizing?cap:-cap;
      let mode="full";
      const child = observeSibling(ctx,best.value===limit,()=>withChild(p,action,ctx,next=>{`);
edit('if(maximizing?reduced.value<=alpha:reduced.value>=beta)return reduced;',
  'if(maximizing?reduced.value<=alpha:reduced.value>=beta){mode="reduced";return reduced;}');
edit('let result=maximizing?visit(next,depth-1', 'mode="null";let result=maximizing?visit(next,depth-1');
edit('{ctx.pvsResearches++;result=visit(next,depth-1','{mode="full";ctx.pvsResearches++;result=visit(next,depth-1');
edit('return result;\n      });','return result;\n      }));\n      if(Math.abs(child.value)>cap)ctx.options.onMateAudit("bound",child.value,depth);\n      if(child.value===limit && best.value!==limit)ctx.options.onMateAudit("attained",mode);');
writeFileSync(path,code);
const {analyzeAction:b}=await import('./instrumented/bot.js');
const rules={allowCheckingDrops:false,experiment:'capture-bank',bankCapacity:6};
const initialSeed=20263319;
let seed=initialSeed;
const random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
const cases=[];
for(let id=0;id<32;id++){
 const target=[8,16,24,32][id%4],transcript=[];
 let p=r.createInitialPosition(rules);
 for(let i=0;i<target&&!r.getResult(p);i++){
  const legal=r.legalActions(p).sort((a,b)=>r.actionKey(a)<r.actionKey(b)?-1:1),action=legal[Math.floor(random()*legal.length)];
  transcript.push(action);p=r.applyAction(p,action);
 }
 cases.push({id,target,position:p,transcript,result:r.getResult(p)});
}
const options={profile:'competitive',depth:4,iterativeDeepening:true,maxMillis:200,maxNodes:100000,quiescenceDepth:4,quiescenceChecks:true,quiescenceEvasionDepth:2,lateMoveReduction:false,cacheEvaluation:true,cacheQuiescence:false,reducePrincipalVariation:true,reduceQuietDrops:false,stopOnProvenWin:false};
const rows=[],errors=[];
for(const {id,position:p,result:terminal} of cases){
 const queries={},events=[];let avoided=0;
 for(const arm of ['control','instrumented']){
  const snapshot=JSON.stringify(p),t=performance.now();
  const onMateAudit=(kind,...data)=>{
   if(kind==='tail'){avoided++;return;}
   if(kind==='static'||kind==='bound')errors.push({id,kind,data});
   events.push([kind,...data]);
  };
  const result=(arm==='control'?a:b)(p,{...options,...(arm==='instrumented'?{onMateAudit}:{})});
  queries[arm]={elapsed:performance.now()-t,result};
  assert.equal(JSON.stringify(p),snapshot);
  if(terminal)assert.equal(result.action,null);
  else{
   r.applyAction(p,result.action);
   if(result.pv.length)assert.deepEqual(result.pv[0],result.action);
   let next=p;for(const action of result.pv)next=r.applyAction(next,action);
  }
 }
 const left=queries.control.result,right=queries.instrumented.result;
 const complete=terminal||[left,right].every(x=>x.completedDepth===4&&!x.stopped);
 if(complete)for(const key of ['action','score','pv','nodes','completedDepth'])
  if(JSON.stringify(left[key])!==JSON.stringify(right[key]))errors.push({id,field:key});
 rows.push({id,complete:!!complete,queries,events,avoided});
}
const complete=rows.filter(r=>r.complete);
const visits=complete.reduce((n,r)=>n+r.queries.instrumented.result.nodes,0),avoided=complete.reduce((n,r)=>n+r.avoided,0),roots=complete.filter(r=>r.avoided>0).length;
const summary={complete:complete.length,visits,avoided,roots,fraction:visits?avoided/visits:0,terminal:cases.filter(c=>c.result).length,errors:errors.length,pass:complete.length>=28&&!errors.length&&avoided>=0.05*visits&&roots>=8};
writeFileSync(new URL('./results.json',import.meta.url),JSON.stringify({initialSeed,finalSeed:seed,rules,options,cases,rows,errors,summary}));
console.log(JSON.stringify(summary));
