#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
test ! -e state.txt
printf 'active\n' > state.txt
trap 'status=$?; if [ "$status" = 0 ]; then printf "inactive: completed\n" > state.txt; else printf "inactive: failed (%s)\n" "$status" > state.txt; fi' EXIT
node --version > environment.txt
uname -sm >> environment.txt
shasum -a 256 PLAN.md run.mjs verify.mjs launch.sh control/*.js candidate/*.js portable/* rule-fixtures.json timed-settings.json > SOURCE-SHA256SUMS
node run.mjs verify > transitions.log 2>&1
node portable/check-engine-contract.js > contract.log 2>&1
node --test portable/*test.js > mates.log 2>&1
node run.mjs timing > timing.log 2>&1
shasum -a 256 -c SOURCE-SHA256SUMS > verification.log
node verify.mjs > replay-verification.log
test "$(wc -l < timing.jsonl | tr -d ' ')" = 256
