import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import * as r from './baseline/rules.js';
import {analyzeAction as a} from './baseline/bot.js';
const path=new URL('./instrumented/bot.js',import.meta.url);
const original=readFileSync(new URL('./baseline/bot.js',import.meta.url),'utf8');
const anchor='score+=positionalScore(position,masks,facts.options.kingEscapeGeometry)*(player===WHITE?1:-1);';
assert.equal(original.split(anchor).length,2);
writeFileSync(path,original.replace(anchor,`const subtotal=positionalScore(position,masks,facts.options.kingEscapeGeometry);
    facts.options.onSubtotal(position.board,subtotal);
    score+=subtotal*(player===WHITE?1:-1);`));
const {analyzeAction:b}=await import('./instrumented/bot.js');
const rules={allowCheckingDrops:false,experiment:'capture-bank',bankCapacity:6};
const initialSeed=20263217;
let seed=initialSeed;
const random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
const cases=[];
for(let id=0;id<32;id++){
 const target=[8,16,24,32][id%4],transcript=[];
 let p=r.createInitialPosition(rules);
 for(let i=0;i<target&&!r.getResult(p);i++){
  const legal=r.legalActions(p),action=legal[Math.floor(random()*legal.length)];
  transcript.push(action);p=r.applyAction(p,action);
 }
 cases.push({id,target,position:p,transcript,result:r.getResult(p)});
}
const options={profile:'competitive',depth:4,iterativeDeepening:true,maxMillis:200,maxNodes:100000,quiescenceDepth:4,quiescenceChecks:true,quiescenceEvasionDepth:2,lateMoveReduction:false,cacheEvaluation:true,cacheQuiescence:false,reducePrincipalVariation:true,reduceQuietDrops:false,stopOnProvenWin:false};
const rows=[],errors=[];
for(const {id,position:p,result:terminal} of cases){
 const queries={},events=[],seen=new Map();
 for(const arm of ['control','instrumented']){
  const snapshot=JSON.stringify(p),t=performance.now();
  const onSubtotal=(board,value)=>{
   const key=board.map(o=>o?o.owner+':'+o.piece:'-').join(',');
   if(seen.has(key)&&seen.get(key)!==value)errors.push({id,key,value,prior:seen.get(key)});
   events.push([key,value]);seen.set(key,value);
  };
  const result=(arm==='control'?a:b)(p,{...options,...(arm==='instrumented'?{onSubtotal}:{})});
  queries[arm]={elapsed:performance.now()-t,result};
  assert.equal(JSON.stringify(p),snapshot);
  if(terminal)assert.equal(result.action,null);
  else{
   r.applyAction(p,result.action);
   if(result.pv.length)assert.deepEqual(result.pv[0],result.action);
   let next=p;for(const action of result.pv)next=r.applyAction(next,action);
  }
 }
 const left=queries.control.result,right=queries.instrumented.result;
 const complete=terminal||[left,right].every(x=>x.completedDepth===4&&!x.stopped);
 if(complete)for(const key of ['action','score','pv','nodes','completedDepth'])
  if(JSON.stringify(left[key])!==JSON.stringify(right[key]))errors.push({id,field:key});
 rows.push({id,complete:!!complete,queries,events,duplicates:events.length-seen.size});
}
const complete=rows.filter(r=>r.complete);
const calls=complete.reduce((n,r)=>n+r.events.length,0), duplicates=complete.reduce((n,r)=>n+r.duplicates,0), roots=complete.filter(r=>r.duplicates>0).length;
const summary={complete:complete.length,calls,duplicates,roots,fraction:calls?duplicates/calls:0,terminal:cases.filter(c=>c.result).length,errors:errors.length,pass:complete.length>=28&&!errors.length&&duplicates>=0.1*calls&&roots>=8};
writeFileSync(new URL('./results.json',import.meta.url),JSON.stringify({initialSeed,finalSeed:seed,rules,options,cases,rows,errors,summary}));
console.log(JSON.stringify(summary));
