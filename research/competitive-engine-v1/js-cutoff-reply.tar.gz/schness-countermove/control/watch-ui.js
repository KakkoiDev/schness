import {
  BANK_PIECES, BLACK, KING, WHITE, applyAction, createInitialPosition, getResult, isInCheck,
} from './rules.js';
import { VARIANTS, VARIANT_IDS, VARIANT_LABELS, resolveVariant, description, variantSettings } from './variants.js';
import { hiddenSetupPlacements } from './tournament.js';
import { pairMoves, recordAction } from './history.js';
import { refusedDrops, DROP_REFUSAL, actionAt, actionsForSelection, bankSelection, boardSelection, setupActionAt, setupDestinations } from './interaction.js';
import { buildEditedPosition, controllerSearch, humanSeatControllers, putEditorPiece } from './arena.js';
import { movedEnough } from './drag.js';
import { createBoard, pieceElement, renderBoard, renderReserve as renderPieceReserve } from './board-ui.js';
import { initTheme } from './theme.js';
import { initI18n, translateText } from './i18n.js';
import { attachAnalysis } from './analysis-ui.js';
import { resultLabel, sideName } from './watch.js';

initTheme();
initI18n();
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js'));

const $ = (selector) => document.querySelector(selector);
const board = $('#watch-board');
const status = $('#watch-status');
const moves = $('#watch-moves');
const worker = new Worker('./src/bot-worker.js', { type: 'module' });
let chosenVariant = 'canonical';
let variantChoice = 'canonical';
let variantSeed = 0;
try {
  const settings = variantSettings(location.search);
  chosenVariant = settings.id;
  variantChoice = new URLSearchParams(location.search).get('variant') === 'random' ? 'random' : settings.id;
  variantSeed = settings.seed;
  if (variantChoice === 'random') {
    variantSeed = crypto.getRandomValues(new Uint32Array(1))[0];
    const url = new URL(location.href); url.searchParams.set('variant', chosenVariant); url.searchParams.set('seed', String(variantSeed));
    window.history.replaceState(null, '', url);
  }
} catch {
  // An invalid link never chooses an unrecognized ruleset.
  document.querySelector('#variant-description').textContent = 'Unsupported variant link; using Classic Schness.';
}
let timeline = [createInitialPosition(VARIANTS[chosenVariant])];
let history = [];
let reviewIndex = 0;
let selection = null;
let request = 0;
let thinking = false;
let aisPaused = false;
let nextMoveTimer;
let editorBoard = [];
let editorPiece = { owner: WHITE, piece: KING };
let pointerDrag = null;
let suppressClick = false;
const trainingAnalysis = attachAnalysis({
  toggles: { mate: $('#watch-training-mate'), advantage: $('#watch-training-advantage') },
  bar: $('#watch-analysis-bar'), fill: $('#watch-analysis-fill'),
  scoreLabel: $('#watch-analysis-score'), warning: $('#watch-training-warning'),
  getPosition: current, enabled: () => current().phase === 'play',
  showRisks: () => reviewIndex === history.length && controller(current().turn) === 'human',
});
let analyzedPosition = null;

const imported = loadImportedPosition();
if (imported) { timeline = [imported]; chosenVariant = variantChoice = 'canonical'; }

buildBoard(board, false);
buildBoard($('#position-board'), true);
buildEditorTools();
bindControls();
render();

function loadImportedPosition() {
  if (new URLSearchParams(location.search).get('position') !== 'library') return null;
  try {
    const saved = JSON.parse(sessionStorage.getItem('schness-arena-position'));
    sessionStorage.removeItem('schness-arena-position');
    return buildEditedPosition(saved.board, saved.turn);
  } catch {
    return null;
  }
}

function bindControls() {
  const variantSelect = $('#game-variant');
  variantSelect.replaceChildren(...['random', ...VARIANT_IDS].map(id => {
    const option = document.createElement('option'); option.value = id;
    option.textContent = id === 'random' ? 'Random variant' : VARIANT_LABELS[id]; return option;
  }));
  variantSelect.value = variantChoice;
  variantSelect.addEventListener('change', () => { variantChoice = variantSelect.value; restart(); });
  $('#human-side').addEventListener('change', () => {
    const seats = humanSeatControllers($('#human-side').value, controller(WHITE), controller(BLACK));
    $('#white-level').value = seats.white;
    $('#black-level').value = seats.black;
    /*
     * Taking a seat mid-game restarts, because the moves so far were somebody
     * else's. Before the first move there is nothing to throw away — and a
     * position imported from the library is exactly that case, so choosing a
     * side used to delete the position you came here to play.
     */
    if (history.length) return restart();
    cancelSearch();
    selection = null;
    goLive(false);
    render();
    scheduleBot();
  });
  $('#watch-first').addEventListener('click', () => reviewTo(0));
  $('#watch-previous').addEventListener('click', () => review(-1));
  $('#watch-next').addEventListener('click', () => review(1));
  $('#watch-last').addEventListener('click', () => reviewTo(history.length));
  $('#watch-live').addEventListener('click', goLive);
  $('#watch-branch').addEventListener('click', branchHere);
  $('#watch-auto').addEventListener('click', () => {
    aisPaused = !aisPaused;
    cancelSearch();
    render();
    scheduleBot();
  });
  $('#watch-restart').addEventListener('click', restart);
  $('#watch-edit').addEventListener('click', openEditor);
  $('#position-close').addEventListener('click', () => $('#position-dialog').close());
  $('#position-clear').addEventListener('click', () => { editorBoard = Array(16).fill(null); renderEditor(); });
  $('#position-apply').addEventListener('click', applyEditor);
  for (const select of [$('#white-level'), $('#black-level')]) {
    select.addEventListener('change', () => {
      cancelSearch();
      selection = null;
      goLive(false);
      render();
      scheduleBot();
    });
  }
  worker.addEventListener('message', receiveBotMove);
  document.addEventListener('pointermove', movePointerDrag, { passive: false });
  document.addEventListener('pointerup', endPointerDrag);
  document.addEventListener('pointercancel', cancelPointerDrag);
}

function controller(side) {
  return $(side === WHITE ? '#white-level' : '#black-level').value;
}

function current() {
  return timeline[reviewIndex];
}

function live() {
  return timeline.at(-1);
}

function cancelSearch() {
  request += 1;
  thinking = false;
  clearTimeout(nextMoveTimer);
}

function receiveBotMove({ data }) {
  if (data.request !== request) return;
  thinking = false;
  if (data.error) {
    status.textContent = `AI error: ${data.error}`;
    aisPaused = true;
    return render();
  }
  if (!data.action || aisPaused || reviewIndex !== history.length || controller(live().turn) === 'human') return render();
  playAction(data.action, true);
}

function scheduleBot() {
  clearTimeout(nextMoveTimer);
  const position = live();
  const search = controllerSearch(controller(position.turn));
  if (aisPaused || thinking || reviewIndex !== history.length || getResult(position) || !search) return render();
  thinking = true;
  request += 1;
  render();
  worker.postMessage({ position, ...search, request });
}

function playAction(action, botMoved = false) {
  const before = live();
  const after = applyAction(before, action);
  history = recordAction(history, before, action, after);
  Object.assign(history[history.length - 1], { mover: before.turn, phase: before.phase });
  timeline.push(after);
  if (after.phase === 'setup' && after.rules.hiddenSetup) {
    const kings = { white: after.board.findIndex(p => p?.owner === WHITE && p.piece === KING), black: after.board.findIndex(p => p?.owner === BLACK && p.piece === KING) };
    const armies = hiddenSetupPlacements(kings, variantSeed);
    for (let slot = 0; slot < 3; slot++) for (const player of [WHITE, BLACK]) {
      const previous = timeline.at(-1), drop = armies[player][slot];
      const next = applyAction(previous, drop);
      history = recordAction(history, previous, drop, next);
      Object.assign(history[history.length - 1], { mover: player, phase: 'setup', simultaneousReveal: true });
      timeline.push(next);
    }
  }
  reviewIndex = history.length;
  selection = null;
  render();
  if (!getResult(after)) {
    if (botMoved) nextMoveTimer = setTimeout(scheduleBot, 700);
    else scheduleBot();
  }
}

function chooseSquare(square) {
  if (suppressClick) return;
  const position = current();
  if (reviewIndex !== history.length || getResult(position) || controller(position.turn) !== 'human') return;
  if (position.phase.startsWith('place-')) {
    const action = setupActionAt(position, square);
    if (action) playAction(action);
    return;
  }
  const action = actionAt(position, selection, square);
  if (action) return playAction(action);
  if (refusedDrops(position, selection).has(square)) { status.textContent = DROP_REFUSAL; return; }
  const occupant = position.board[square];
  selection = occupant?.owner === position.turn ? boardSelection(square) : null;
  render();
}

function chooseReserve(piece) {
  if (suppressClick) return;
  const position = current();
  if (reviewIndex !== history.length || getResult(position) || controller(position.turn) !== 'human' || position.phase.startsWith('place-')) return;
  selection = selection?.type === 'bank' && selection.piece === piece ? null : bankSelection(piece);
  render();
}

function review(direction) {
  reviewTo(reviewIndex + direction);
}

function reviewTo(index) {
  aisPaused = true;
  cancelSearch();
  reviewIndex = Math.max(0, Math.min(history.length, index));
  selection = null;
  render();
}

function goLive(resume = true) {
  reviewIndex = history.length;
  selection = null;
  if (resume) aisPaused = false;
  render();
  scheduleBot();
}

function branchHere() {
  if (reviewIndex === history.length) return;
  history = history.slice(0, reviewIndex);
  timeline = timeline.slice(0, reviewIndex + 1);
  aisPaused = false;
  selection = null;
  render();
  scheduleBot();
}

function restart() {
  cancelSearch();
  chosenVariant = resolveVariant(variantChoice);
  variantSeed = crypto.getRandomValues(new Uint32Array(1))[0];
  const url = new URL(location.href);
  url.searchParams.delete('position');
  url.searchParams.set('variant', chosenVariant);
  url.searchParams.set('seed', String(variantSeed));
  window.history.replaceState(null, '', url);
  timeline = [createInitialPosition(VARIANTS[chosenVariant])];
  history = [];
  reviewIndex = 0;
  selection = null;
  aisPaused = false;
  render();
  scheduleBot();
}

function buildBoard(element, editor) {
  createBoard(element, {
    onSquare: (square) => editor ? editSquare(square) : chooseSquare(square),
    onPointerDown: editor ? undefined : (event, square, button) => beginBoardDrag(event, square, button),
  });
}

function render() {
  const position = current();
  $('#variant-description').textContent = `${translateText(VARIANT_LABELS[chosenVariant])} · ${translateText(description(position.rules))}${chosenVariant === 'canonical' ? '' : ` ${translateText('Experimental rules.')}`}`;
  if (position !== analyzedPosition) {
    analyzedPosition = position;
    trainingAnalysis.refresh();
  }
  const humanTurn = reviewIndex === history.length && controller(position.turn) === 'human';
  const legal = selection ? actionsForSelection(position, selection) : [];
  const placements = position.phase.startsWith('place-') ? setupDestinations(position) : new Set();
  const targets = position.phase.startsWith('place-') ? new Set(placements) : new Set(legal.map(action => action.to));
  const last = history[reviewIndex - 1]?.action;
  renderBoard(board, position, {
    last, selected: selection?.type === 'board' ? selection.square : null, targets,
    refused: humanTurn ? refusedDrops(position, selection) : new Set(),
    placements: humanTurn ? placements : new Set(),
    dragging: pointerDrag?.active ? pointerDrag.selection?.square : null, disabled: !humanTurn,
  });
  renderReserve('#white-reserve', position.banks[WHITE], WHITE);
  renderReserve('#black-reserve', position.banks[BLACK], BLACK);
  renderMoves();
  const result = getResult(position);
  const yours = controller(position.turn) === 'human';
  let eyebrow = yours ? 'Your move' : `${sideName(position.turn)} to move`;
  if (reviewIndex < history.length) {
    eyebrow = 'Reviewing';
    status.textContent = `Reviewing ply ${reviewIndex} of ${history.length}`;
  } else if (result) {
    eyebrow = 'Game over';
    status.textContent = resultLabel(result);
  } else if (thinking) {
    eyebrow = 'Thinking';
    status.textContent = `${sideName(position.turn)} ${controller(position.turn)} is thinking…`;
  } else if (aisPaused && !yours) {
    eyebrow = 'Paused';
    status.textContent = `Paused before ${sideName(position.turn)} moves`;
  } else if (position.phase === 'setup') {
    eyebrow = 'Army setup';
    status.textContent = `${sideName(position.turn)}: choose a reserve piece and place it without check`;
  } else if (position.phase !== 'play') {
    eyebrow = yours ? 'Your move' : 'Placing kings';
    status.textContent = `${sideName(position.turn)}: place your king on the home row`;
  } else if (yours && isInCheck(position, position.turn)) {
    eyebrow = 'Check';
    status.textContent = 'CHECK — defend your king';
  } else {
    status.textContent = `${sideName(position.turn)} to move · ${yours ? 'Your seat' : controller(position.turn)}`;
  }
  $('#watch-eyebrow').textContent = eyebrow;
  document.querySelector('.arena-turn').classList.toggle('is-check', eyebrow === 'Check');
  renderControls();
}

function renderReserve(selector, pieces, owner) {
  const element = $(selector);
  const interactive = reviewIndex === history.length && current().turn === owner && controller(owner) === 'human';
  renderPieceReserve(element, pieces, owner, {
    interactive,
    selected: selection?.type === 'bank' && current().turn === owner ? selection.piece : null,
    dragging: pointerDrag?.active ? pointerDrag.selection?.piece : null,
    disabled: !interactive,
    onSelect: chooseReserve,
    onPointerDown: beginBankDrag,
  });
}

function beginBoardDrag(event, square, button) {
  const position = current();
  const occupant = position.board[square];
  if (!event.isPrimary || reviewIndex !== history.length || controller(position.turn) !== 'human' ||
      position.phase !== 'play' || occupant?.owner !== position.turn || getResult(position)) return;
  pointerDrag = dragStart(event, boardSelection(square), occupant.owner, occupant.piece, button);
}

function beginBankDrag(event, piece, button) {
  const position = current();
  if (!event.isPrimary || reviewIndex !== history.length || controller(position.turn) !== 'human' ||
      position.phase.startsWith('place-') || getResult(position)) return;
  pointerDrag = dragStart(event, bankSelection(piece), position.turn, piece, button);
}

function dragStart(event, chosen, owner, piece, element) {
  return { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY,
    selection: chosen, owner, piece, pieceRect: element.querySelector('.piece')?.getBoundingClientRect() };
}

function movePointerDrag(event) {
  if (!pointerDrag || pointerDrag.pointerId !== event.pointerId) return;
  if (!pointerDrag.active && movedEnough(pointerDrag, event)) {
    pointerDrag.active = true;
    selection = pointerDrag.selection;
    pointerDrag.ghost = pieceElement(pointerDrag.owner, pointerDrag.piece);
    pointerDrag.ghost.classList.add('drag-ghost');
    if (pointerDrag.pieceRect) Object.assign(pointerDrag.ghost.style, {
      width: `${pointerDrag.pieceRect.width}px`, height: `${pointerDrag.pieceRect.height}px`,
    });
    document.body.append(pointerDrag.ghost);
    render();
  }
  if (!pointerDrag.active) return;
  event.preventDefault();
  Object.assign(pointerDrag.ghost.style, { left: `${event.clientX}px`, top: `${event.clientY}px` });
}

function endPointerDrag(event) {
  if (!pointerDrag || pointerDrag.pointerId !== event.pointerId) return;
  const ended = pointerDrag;
  pointerDrag = null;
  ended.ghost?.remove();
  if (!ended.active) return;
  const target = document.elementFromPoint(event.clientX, event.clientY)?.closest('#watch-board .square');
  const action = target ? actionAt(current(), ended.selection, Number(target.dataset.square)) : null;
  event.preventDefault();
  suppressClick = true;
  setTimeout(() => { suppressClick = false; }, 0);
  if (action) playAction(action); else {
    const refused = target && refusedDrops(current(), ended.selection).has(Number(target.dataset.square));
    selection = refused ? ended.selection : null;
    render();
    if (refused) status.textContent = DROP_REFUSAL;
  }
}

function cancelPointerDrag() {
  pointerDrag?.ghost?.remove();
  pointerDrag = null;
  selection = null;
  render();
}

/**
 * Numbered, paired, tabular. It was a flat run of ghost buttons, one per ply,
 * which is a list of moves rather than a transcript you can follow.
 */
function renderMoves() {
  const rows = pairMoves(history);
  moves.replaceChildren(...rows.map((row) => {
    const line = document.createElement('div');
    line.className = 'arena-move-row';
    line.setAttribute('role', 'row');
    const number = document.createElement('span');
    number.setAttribute('role', 'cell');
    number.textContent = String(row.number);
    line.append(number, moveCell(row.white), moveCell(row.black));
    return line;
  }));
  const currentMove = moves.querySelector('.is-current');
  if (currentMove) {
    const top = currentMove.offsetTop;
    const bottom = top + currentMove.offsetHeight;
    if (top < moves.scrollTop) moves.scrollTop = top;
    else if (bottom > moves.scrollTop + moves.clientHeight) moves.scrollTop = bottom - moves.clientHeight;
  }
}

function moveCell(entry) {
  if (!entry) {
    const blank = document.createElement('span');
    blank.setAttribute('role', 'cell');
    return blank;
  }
  const button = document.createElement('button');
  button.type = 'button';
  button.setAttribute('role', 'cell');
  button.className = entry.ply === reviewIndex ? 'arena-move is-current' : 'arena-move';
  button.textContent = entry.notation;
  button.addEventListener('click', () => reviewTo(entry.ply));
  return button;
}

function renderControls() {
  const seat = controller(WHITE) === 'human' ? WHITE : controller(BLACK) === 'human' ? BLACK : 'watch';
  $('#human-side').value = seat;
  // A strength control exists for each side that actually has a bot on it.
  $('#white-strength').hidden = controller(WHITE) === 'human';
  $('#black-strength').hidden = controller(BLACK) === 'human';
  const atStart = reviewIndex === 0;
  const atLive = reviewIndex === history.length;
  $('#watch-first').disabled = atStart;
  $('#watch-previous').disabled = atStart;
  $('#watch-next').disabled = atLive;
  $('#watch-last').disabled = atLive;
  $('#watch-live').disabled = atLive;
  $('#watch-branch').disabled = atLive || (current().rules?.hiddenSetup && current().phase === 'setup');
  $('#watch-auto').textContent = aisPaused ? 'Resume the bots' : 'Pause the bots';
  $('#watch-auto').setAttribute('aria-pressed', String(aisPaused));
}

function buildEditorTools() {
  const tools = $('#position-tools');
  for (const owner of [WHITE, BLACK]) {
    for (const piece of [KING, ...BANK_PIECES]) {
      const button = document.createElement('button');
      button.type = 'button';
      button.dataset.owner = owner;
      button.dataset.piece = piece;
      button.append(pieceElement(owner, piece));
      button.setAttribute('aria-label', `${owner} ${piece}`);
      button.addEventListener('click', () => { editorPiece = { owner, piece }; renderEditor(); });
      tools.append(button);
    }
  }
  tools.querySelector('[data-piece="erase"]').addEventListener('click', () => { editorPiece = null; renderEditor(); });
}

function openEditor() {
  aisPaused = true;
  cancelSearch();
  editorBoard = current().board.map((occupant) => occupant ? { ...occupant } : null);
  $('#position-turn').value = current().turn;
  $('#position-error').textContent = '';
  render();
  renderEditor();
  $('#position-dialog').showModal();
}

function editSquare(square) {
  editorBoard = putEditorPiece(editorBoard, square, editorPiece);
  $('#position-error').textContent = '';
  renderEditor();
}

function renderEditor() {
  renderBoard($('#position-board'), { board: editorBoard });
  for (const button of $('#position-tools').querySelectorAll('button')) {
    const selected = editorPiece === null ? button.dataset.piece === 'erase'
      : button.dataset.owner === editorPiece.owner && button.dataset.piece === editorPiece.piece;
    button.classList.toggle('selected', selected);
  }
}

function applyEditor() {
  try {
    const position = buildEditedPosition(editorBoard, $('#position-turn').value);
    chosenVariant = variantChoice = 'canonical';
    $('#game-variant').value = 'canonical';
    const url = new URL(location.href); url.searchParams.delete('variant'); url.searchParams.delete('seed');
    window.history.replaceState(null, '', url);
    timeline = [position];
    history = [];
    reviewIndex = 0;
    selection = null;
    aisPaused = false;
    $('#position-dialog').close();
    render();
    scheduleBot();
  } catch (error) {
    $('#position-error').textContent = error.message;
  }
}
