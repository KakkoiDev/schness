const STORAGE_KEY = 'schness-language';
const SUPPORTED = new Set(['en', 'ja']);

const JA = new Map(Object.entries({
  'A dropped piece may not give check.': '配置した駒で王手はできません。',
  'A dropped piece may not give check. Your piece is still in reserve.': '配置した駒で王手はできません。持ち駒の選択はそのままです。',
  "Permanent captures · quiet drops": "捕獲駒は除去・王手配置なし",
  "Permanent captures · checking drops": "捕獲駒は除去・王手配置あり",
  "Captured pieces leave the game permanently; unused reserves can still deploy. Checking drops allowed.": "取られた駒は対局から永久に除去。未使用の持ち駒は配置できます。王手配置は許可。",
  "Captured pieces leave the game permanently; unused reserves can still deploy. Checking drops forbidden.": "取られた駒は対局から永久に除去。未使用の持ち駒は配置できます。王手配置は禁止。",
  "Capture bank 3 · checking drops": "持ち駒上限3・王手配置許可",
  "Captured pieces join your bank up to 3 held pieces; overflow returns to the captured side. Checking drops allowed.": "持ち駒上限は3駒。捕獲駒を獲得し、満杯なら取られた側へ戻します。王手配置は許可。",
  "Capture bank 3 · quiet drops": "持ち駒上限3・王手配置禁止",
  "Captured pieces join your bank up to 3 held pieces; overflow returns to the captured side. Checking drops forbidden.": "持ち駒上限は3駒。捕獲駒を獲得し、満杯なら取られた側へ戻します。王手配置は禁止。",
  "Capture bank 4 · checking drops": "持ち駒上限4・王手配置許可",
  "Captured pieces join your bank up to 4 held pieces; overflow returns to the captured side. Checking drops allowed.": "持ち駒上限は4駒。捕獲駒を獲得し、満杯なら取られた側へ戻します。王手配置は許可。",
  "Capture bank 4 · quiet drops": "持ち駒上限4・王手配置禁止",
  "Captured pieces join your bank up to 4 held pieces; overflow returns to the captured side. Checking drops forbidden.": "持ち駒上限は4駒。捕獲駒を獲得し、満杯なら取られた側へ戻します。王手配置は禁止。",
  "Capture bank 5 · checking drops": "持ち駒上限5・王手配置許可",
  "Captured pieces join your bank up to 5 held pieces; overflow returns to the captured side. Checking drops allowed.": "持ち駒上限は5駒。捕獲駒を獲得し、満杯なら取られた側へ戻します。王手配置は許可。",
  "Capture bank 5 · quiet drops": "持ち駒上限5・王手配置禁止",
  "Captured pieces join your bank up to 5 held pieces; overflow returns to the captured side. Checking drops forbidden.": "持ち駒上限は5駒。捕獲駒を獲得し、満杯なら取られた側へ戻します。王手配置は禁止。",
  "Capture bank 6 · checking drops": "持ち駒上限6・王手配置許可",
  "Captured pieces join your bank up to 6 held pieces; overflow returns to the captured side. Checking drops allowed.": "持ち駒上限は6駒。捕獲駒を獲得し、満杯なら取られた側へ戻します。王手配置は許可。",
  "Capture bank 6 · quiet drops": "持ち駒上限6・王手配置禁止",
  "Captured pieces join your bank up to 6 held pieces; overflow returns to the captured side. Checking drops forbidden.": "持ち駒上限は6駒。捕獲駒を獲得し、満杯なら取られた側へ戻します。王手配置は禁止。",
  "Capture to bank · quiet drops": "捕獲駒を持ち駒に・王手配置なし",
  "Capture to bank · checking drops": "捕獲駒を持ち駒に・王手配置あり",
  "Four-slot capture bank · quiet drops": "持ち駒上限4・王手配置なし",
  "Four-slot capture bank · checking drops": "持ち駒上限4・王手配置あり",
  "Captured pieces join the capturer’s bank and change sides when dropped. Checking drops allowed.": "捕獲した駒は捕獲側の持ち駒となり、配置すると味方になります。王手配置は許可。",
  "Captured pieces join the capturer’s bank if fewer than four pieces are held; otherwise return to the captured side’s bank. Checking drops allowed.": "持ち駒が4駒未満なら捕獲駒を獲得し、満杯なら取られた側の持ち駒へ戻します。王手配置は許可。",
  "Captured pieces join the capturer’s bank and change sides when dropped. Checking drops forbidden.": "捕獲した駒は捕獲側の持ち駒となり、配置すると味方になります。王手配置は禁止。",
  "Captured pieces join the capturer’s bank if fewer than four pieces are held; otherwise return to the captured side’s bank. Checking drops forbidden.": "持ち駒が4駒未満なら捕獲駒を獲得し、満杯なら取られた側の持ち駒へ戻します。王手配置は禁止。",
  "Checking drops from home half": "自陣半分からの王手配置",
  "Distant checking drops": "離れたマスからの王手配置",
  "Supported checking drops": "味方の支援がある王手配置",
  "Counterchecking drops only": "王手への応手のみ王手配置",
  "Knight checking drops only": "ナイトのみ王手配置",
  "Bishop checking drops only": "ビショップのみ王手配置",
  "Rook checking drops only": "ルークのみ王手配置",
  "Checking drops allowed only onto your own half of the board.": "自陣側の半分に配置する場合のみ王手を許可します。",
  "Checking drops must land at least two king-steps from the opposing king.": "相手キングからキングの動きで2歩以上離れたマスのみ王手配置を許可します。",
  "Checking drops must be supported by another friendly piece, including the king; pinned supporters count.": "キングを含む味方の駒が支援するマスのみ王手配置を許可します。ピンされた支援駒も含みます。",
  "Checking drops allowed only when your king is already in check; the drop must also resolve that check.": "自分が王手されている場合のみ王手配置を許可します。同時に自分の王手も解消する必要があります。",
  "Only knights may give check on a drop; other pieces must drop quietly.": "配置による王手はナイトのみ。他の駒は王手せず配置します。",
  "Only bishops may give check on a drop; other pieces must drop quietly.": "配置による王手はビショップのみ。他の駒は王手せず配置します。",
  "Only rooks may give check on a drop; other pieces must drop quietly.": "配置による王手はルークのみ。他の駒は王手せず配置します。",
  "Each player’s first post-king turn forbids checking drops; later checking drops allowed.": "キング配置後の最初の手は双方とも王手配置禁止。その後は許可します。",
  "Recurring lone-king protection plus a quiet first post-king turn for both players.": "双方の初手は王手配置禁止。相手がキングのみなら再び保護します。",
  "Checking drops unlock permanently for both players after both have first deployed one non-king.": "双方がキング以外を1駒配置すると、王手配置を以後許可します。",
  "Checking drops unlock permanently after both players have deployed two distinct non-kings.": "双方が異なる2駒を配置すると、王手配置を以後許可します。",
  "Each player may make at most one checking drop per game.": "各プレイヤーの王手配置は対局中1回までです。",
  "A checking drop must be followed on that player’s next turn by a move or quiet drop.": "王手配置した次の自分の手番は、移動か王手しない配置に限ります。",
  "Checking drops allowed unless the drop immediately checkmates.": "配置による王手は許可しますが、即チェックメイトは禁止です。",
  "Checking drops forbidden whenever the opponent has only a king deployed; protection returns after captures.": "相手の盤上駒がキングのみなら王手配置禁止。捕獲後も保護が戻ります。",
  "Checking drops forbidden until the opponent first deploys a non-king; protection never returns.": "相手がキング以外を初めて配置するまで王手配置禁止。その後は保護しません。",
  "Checking drops permitted only after both players have completed three turns following king placement.": "双方がキング配置後に3手終えるまで王手配置は禁止です。",
  "Same three-turn grace period; a piece that has previously been deployed can never check on a later drop.": "最初の3手は王手配置禁止。配置済みの駒は再配置で王手できません。",
  "White: choose a reserve piece and place it without check": "白：持ち駒を選び、王手しないように配置してください",
  "Black: choose a reserve piece and place it without check": "黒：持ち駒を選び、王手しないように配置してください",
  "Alternate quiet drops of all pieces, with no moves or captures during setup. white takes the first normal turn. Later checking drops allowed. No legal setup placement is a setup-blocked draw.": "全駒を交互に王手せず配置し、その間の移動・捕獲は禁止。通常対局は白から。以後の王手配置は許可。配置不能なら引き分けです。",
  "Alternate quiet drops of all pieces, with no moves or captures during setup. white takes the first normal turn. Later checking drops forbidden. No legal setup placement is a setup-blocked draw.": "全駒を交互に王手せず配置し、その間の移動・捕獲は禁止。通常対局は白から。以後の王手配置は禁止。配置不能なら引き分けです。",
  "Alternate quiet drops of all pieces, with no moves or captures during setup. black takes the first normal turn. Later checking drops allowed. No legal setup placement is a setup-blocked draw.": "全駒を交互に王手せず配置し、その間の移動・捕獲は禁止。通常対局は黒から。以後の王手配置は許可。配置不能なら引き分けです。",
  "Alternate quiet drops of all pieces, with no moves or captures during setup. black takes the first normal turn. Later checking drops forbidden. No legal setup placement is a setup-blocked draw.": "全駒を交互に王手せず配置し、その間の移動・捕獲は禁止。通常対局は黒から。以後の王手配置は禁止。配置不能なら引き分けです。",
  "Independently seeded private home-rank arrangements, no initial check, simultaneous reveal; White starts play; checking drops allowed. Uniform legal arrangement sampling, not a hidden-information AI.": "自陣の駒を独立にランダム配置し同時公開。初期王手なし、白先手。王手配置は許可。配置は合法な並びから均等に選びます。",
  "Independently seeded private home-rank arrangements, no initial check, simultaneous reveal; White starts play; checking drops forbidden. Uniform legal arrangement sampling, not a hidden-information AI.": "自陣の駒を独立にランダム配置し同時公開。初期王手なし、白先手。王手配置は禁止。配置は合法な並びから均等に選びます。",
  'Game variant': '対局ルール', 'Random variant': 'ランダムルール',
  'Try a complete experimental ruleset in the Bot arena': 'ボットアリーナで実験ルールを試す',
  'Classic Schness': 'クラシック Schness', 'Checking drops': '王手配置あり',
  'Lone-king protection': 'キング単独時の保護', 'Opening king protection': '序盤のキング保護',
  'Quiet first turn': '初手の王手配置なし', 'Quiet first turn + king protection': '初手制限とキング保護',
  'Both deploy one': '双方1駒配置後に解禁', 'Both deploy two': '双方2駒配置後に解禁',
  'One checking drop': '王手配置は1回', 'Checking-drop cooldown': '王手配置の連続禁止',
  'No drop mate': '配置による即詰み禁止', 'Three-turn grace': '最初の3手は王手配置なし',
  'Quiet return drops': '再配置の王手禁止', 'Army setup': '軍の配置',
  'Canonical quiet drops.': '通常ルール。配置による王手は禁止です。',
  'Unrestricted checking drops.': '配置による王手を許可します。',
  'Experimental rules.': '実験ルールです。',
  'Full setup · quiet drops · White first': '全駒配置・王手配置なし・白先手',
  'Full setup · checking drops · White first': '全駒配置・王手配置あり・白先手',
  'Full setup · quiet drops · Black first': '全駒配置・王手配置なし・黒先手',
  'Full setup · checking drops · Black first': '全駒配置・王手配置あり・黒先手',
  'Random hidden armies · quiet drops': '秘密のランダム配置・王手配置なし',
  'Random hidden armies · checking drops': '秘密のランダム配置・王手配置あり',

  'Schness': 'Schness', 'Dark': 'ダーク', 'Light': 'ライト', 'Rules': 'ルール', 'Sound': 'サウンド', 'Install': 'インストール',
  'Game · Schness': '対局 · Schness', 'Bot arena · Schness': 'ボットアリーナ · Schness', 'Game library · Schness': '棋譜ライブラリ · Schness', 'Checkmate puzzles · Schness': '詰みパズル · Schness',
  'Schness home': 'Schness ホーム', 'Switch to dark mode': 'ダークモードに切り替える', 'Switch to light mode': 'ライトモードに切り替える',
  'Play Schness': 'Schnessで遊ぶ', 'Compact chess · 4 × 4': '小さな盤、大きな一手',
  'Play as': 'プレイヤーの色', 'Watch both bots': 'ボット同士の対戦を観る',
  'Coordinates': '座標',
  "On your turn, either move a piece on the board by normal chess rules, or take a piece from your reserve and place it on any empty square. A deployed piece may not immediately check the opposing king.": '自分の手番では、盤上の駒を通常のチェスのルールで動かすか、持ち駒を空いているマスに配置します。ただし、配置した手で相手のキングにチェックをかけることはできません。',
  'Training': 'トレーニング', 'Forced-mate hints (1–4 moves)': '詰みのヒント（1〜4手）', 'White / Black advantage': '白と黒の形勢',
  'Show estimated advantage': '推定形勢を表示',
  'Checking both sides for forced mates…': '両陣営の詰みを解析中…',
  'No forced mate within four moves for either side.': 'どちらにも4手以内の確定した詰みは見つかりませんでした。',
  'White has mate': '白に詰みあり', 'Black has mate': '黒に詰みあり',
  'Evaluation incomplete': '形勢解析は未完了', 'Analysis unavailable.': '解析を利用できません。',
  'Training tools': '練習ツール', 'Online match': 'オンライン対局', 'Choose a time control': '持ち時間を選択',
  'Time per player': '各プレイヤーの持ち時間', 'Choose untimed or a clock before creating the invitation link.': '招待リンクを作る前に、時間無制限か持ち時間を選んでください。',
  'Create invitation link': '招待リンクを作る', 'Close online setup': '対局設定を閉じる',
  'Move a piece, or deploy one from your reserve. Every capture comes back.': '駒を動かすか、持ち駒を配置。取られた駒はまた戻ってきます。',
  'Bot arena': 'ボットアリーナ', 'Library': '棋譜', 'Puzzles': '詰みパズル', 'Play online': 'オンライン対戦',
  // The rules stepper's own chrome, which shipped in English on the JA site.
  'Back': '戻る', 'Next rule': '次のルール', 'Your match': '対局中', 'The board is 4 × 4': '盤は4×4', 'Play against the bot': 'ボットと対戦', 'Play, watch, take over, or edit a position': '対戦・観戦・途中参加・局面編集',
  'Create an online game': 'オンライン対局を作る', 'Get a link to send a friend': '友だちに送るリンクを作成',
  'Browse recorded games': '棋譜ライブラリ', 'Study 1,099 unique AI games': '1,099局のAI対戦を研究',
  'Checkmate puzzles': '詰みパズル', 'Mate in one, two, three, or four': '1手詰めから4手詰めまで',
  'Settings': '設定', 'Clock': '持ち時間', 'Untimed': '時間無制限', 'Replay interactive tutorial': 'チュートリアルをもう一度',
  'Place the kings': 'キングを配置', 'White sets their king anywhere on the home row, then Black does the same.': '白、黒の順に、自陣の一段目へキングを配置します。',
  'Try it →': '試してみる →', 'Move or deploy': '移動または配置',
  'Each turn: move a piece by normal chess rules, or drop one from your reserve onto an empty square.': '手番では、盤上の駒を動かすか、持ち駒を空いているマスへ配置します。',
  'Nothing is lost': '駒はなくならない', 'A captured piece joins its owner’s reserve, so the board keeps refilling until checkmate.': '取られた駒は元の持ち主の手元へ戻り、チェックメイトまで何度でも使えます。',
  'Playable rule': 'プレイできるルール', 'Close': '閉じる', 'Your turn.': 'あなたの手番です。', 'Restart this rule': 'やり直す',
  'Continue in Bot Arena →': 'ボットアリーナで続ける →', 'Read the full rules': 'ルールをすべて読む',
  'How to play': '遊び方', 'Schness in four rules': '4つでわかるSchness', 'Got it': 'わかった', 'Start playing': '対局をはじめる', 'Skip': 'スキップ', 'Try the board': '盤を試す',
  'The board is 4 × 4': '盤は4×4', 'Files a–d, ranks 1–4. White moves up the board, Black moves down.': '筋はa〜d、段は1〜4。白は上へ、黒は下へ進みます。',
  'Kings go down first': '最初にキングを置く', 'White places their king anywhere on rank 1, then Black places theirs on rank 4. Play begins with White.': '白は1段目、黒は4段目の好きなマスへキングを置きます。その後、白から始めます。',
  'On your turn, either move a piece on the board by normal chess rules, or take a piece from your reserve and place it on any empty square.': '手番では、チェスと同じ動きで盤上の駒を動かすか、持ち駒を空いているマスへ配置します。',
  'Captures come back': '取られた駒は戻る', 'Capturing does not remove a piece. It goes to the reserve of the player who owned it, ready to be deployed again, so material never leaves the game. Win by checkmate.': '取られた駒は消えず、元の持ち主の手元へ戻り、再び配置できます。チェックメイトで勝利です。',
  'Two things that trip people up': '間違えやすい2つの点', 'A deployed piece may not put the enemy king in check on the turn it lands. And a piece dropped on the far row is not promoted; there are no pawns.': '配置したその手で相手のキングをチェックすることはできません。敵陣に配置しても成りません。ポーンはありません。',
  'White’s bishop was captured earlier, so it came back to White’s own reserve. The dashed ring is c2, one of the empty squares it can drop onto.': '白のビショップは取られたため、白の持ち駒に戻っています。点線のc2は配置できる空きマスの一つです。',
  'Home': 'ホーム', 'New game': '新しい対局', 'Play Black': '黒で対戦', 'Play White': '白で対戦', 'Waiting for opponent': '対戦相手を待っています', 'Send this link': 'このリンクを送る',
  'The match starts the moment they open it. You’ll play White.': '相手が開くと対局開始です。あなたは白です。', 'Copy': 'コピー', 'Cancel': 'キャンセル',
  'Play the bot instead': 'ボットと対戦', 'Reconnecting': '再接続中', 'Opponent lost connection': '相手との接続が切れました',
  'The board is saved. If they don’t return within the countdown, the match is yours.': '盤面は保存されています。時間内に戻らなければ、あなたの勝ちです。',
  'Waiting': '待機中', 'Claim the win': '勝利を確定', 'Keep waiting': '待ち続ける', 'Link expired': 'リンクは期限切れです',
  'This game is no longer open': 'この対局には参加できません', 'New online game': '新しいオンライン対局', 'Play the bot': 'ボットと対戦',
  'Back home': 'ホームへ戻る', 'Your turn': 'あなたの手番', 'CHECK — defend your king': '王手！キングを守ってください', 'Deselect': '選択解除', 'Reviewing': '棋譜を確認中',
  'A reviewed board is not the live one. Nothing you do here counts.': '確認中の盤面は現在の局面ではありません。ここでの操作は対局に反映されません。',
  'Back to live': '現在の局面へ', 'Moves': '棋譜', 'Copy game': '棋譜をコピー', 'Undo': '待った', 'Resign': '投了',
  'Take this position further — stronger bots, replay, position editor': 'この局面を引き継いで続ける — 強いボット・再生・局面編集',
  'Place your king on rank 1 and the game runs.': '1段目にキングを置けば対局が始まります。', 'Start again': '最初から',
  'Your move.': 'あなたの手番です。', 'Black is thinking…': '黒が考えています…',
  'You win by checkmate.': 'チェックメイトであなたの勝ちです。', 'Black wins by checkmate.': 'チェックメイトで黒の勝ちです。',
  'A draw. Start again, or take it to the arena.': '引き分けです。最初からか、アリーナで続けられます。',
  'Play against the bot': 'ボットと対戦', 'How to play': '遊び方', 'Source': 'ソース', 'Tournament data': '実験データ', 'Dev log': '開発ログ',
  'More': 'その他', 'Peer-to-peer, no accounts, no tracking.': 'P2P通信・アカウント不要・追跡なし。',
  'No moves yet.': 'まだ指し手はありません。', 'Or scan it': 'または読み取る',
  'The invitation link as a scannable code': '招待リンクの二次元コード',
  'Play the bot while you wait →': '待ちながらボットと対戦 →',
  'The match starts the moment they open it. You play White.': '相手がリンクを開いた瞬間に対局が始まります。あなたは白番です。',
  'Listening for a second player': '相手を待っています',
  'Still listening — no relay is answering yet': '待機中 — 応答するリレーがありません',
  'Still listening — no one has opened the link yet': '待機中 — まだ誰もリンクを開いていません',
  'Nothing yet. Check both browsers opened this exact link, and that neither network blocks a direct connection.': 'まだ接続できません。両方のブラウザが同じリンクを開いているか、直接接続を遮断するネットワークでないかを確認してください。',
  'Connected': '接続しました', 'Black has joined — your move.': '黒が参加しました — あなたの手番です。',
  'White has joined — their move.': '白が参加しました — 相手の手番です。',
  'Peer-to-peer. Nothing about this match passes through a server.': 'P2P通信です。この対局はサーバーを経由しません。',
  'Opponent lost connection': '相手の接続が切れました',
  'The board is saved. If they do not come back before the clock runs out, the match is yours.': '盤面は保存されています。時間切れまでに戻らなければ、あなたの勝ちになります。',
  'until forfeit': '不戦勝まで', 'Keep waiting': '待ち続ける', 'Claim the win': '勝ちを主張', 'Claiming unlocks at 0:00.': '0:00になると主張できます。',
  'This game is no longer open': 'この対局はもう開けません',
  'The invitation was already used, or it sat unopened long enough to go stale. Nothing is lost — a new link takes one tap.': '招待は使用済みか、開かれないまま期限切れになりました。新しいリンクはすぐ作れます。',
  'New invite': '新しい招待', 'Play the bot': 'ボットと対戦', 'Back to the lobby': 'ホームに戻る',
  'Skip': 'スキップ', 'Start playing': '対局をはじめる',
  'Peer-to-peer · not recorded · not stored': 'P2P通信・記録も保存もされません',
  'Focus mode': '集中モード', 'Edit this position': '局面を編集',
  'At the table': '対局チャット', 'On air · mic': '配信中・マイク', 'On air · camera': '配信中・カメラ', 'On air · mic and camera': '配信中・マイクとカメラ',
  'Peer-to-peer · direct': 'P2P・直接接続', 'Focus mode': '集中モード', 'Peer-to-peer · not recorded · not stored': 'P2P通信・保存されません', 'Hide chat': 'チャットを隠す',
  'Audio off': '音声オフ', 'Video off': 'ビデオオフ', 'Hear audio': '相手の音声を聞く', 'No messages yet.': 'まだメッセージはありません。',
  'Good luck': 'よろしくお願いします', 'Nice move': 'いい手ですね', 'Oops': 'しまった', 'Good game': 'ありがとうございました', 'Rematch?': 'もう一局？', 'Offer draw': '引き分けを提案', 'Message your opponent': '相手にメッセージ', 'Send': '送信',
  'Feedback': 'フィードバック', 'Sound and haptics': 'サウンドと振動', 'All off until you ask for them. Reduced motion is about motion, so it does not decide this.': '初期設定ではすべてオフです。必要なものだけ有効にできます。',
  'Move': '移動', 'A soft wooden knock.': '木の駒を置く柔らかな音。', 'Capture': '駒を取る', 'Sharper click, as the piece lands in a reserve.': '取った駒が手元へ戻る、はっきりした音。',
  'Deploy': '配置', 'Distinct from a move, so you hear a drop coming.': '移動と区別できる配置音。', 'Check': 'チェック', 'A low tone, played once.': '低い音を一度鳴らします。',
  'Haptics': '振動', 'A light tap when a piece lands, on phones that support it.': '対応端末で駒を置いたときに軽く振動します。',
  'Keyboard': 'キーボード', 'Playing without a mouse': 'マウスを使わずに遊ぶ',
  'You play': '担当する側', 'White bot': '白のボット', 'Black bot': '黒のボット', 'Neither · watch two bots': '観戦（ボット同士）',
  'Live': '現在', 'Branch from here': 'ここから分岐', 'Edit this position': '局面を編集', 'Pause the bots': 'ボットを一時停止', 'Resume the bots': 'ボットを再開',
  'Your move': 'あなたの手番', 'Reviewing': '再生中', 'Game over': '対局終了', 'Thinking': '思考中', 'Paused': '一時停止', 'Check': '王手', 'Placing kings': 'キングの配置',
  'White to move': '白の手番', 'Black to move': '黒の手番', 'No moves yet.': 'まだ指し手はありません。',
  'Play · watch · experiment': '対戦・観戦・実験', 'Black': '黒', 'White': '白', 'You': 'あなた', 'Learning': '初級', 'Steady': '中級', 'Sharp': '上級',
  'White to move': '白の手番', 'Previous': '戻る', 'Next': '次へ', 'Pause AIs': 'AIを一時停止', 'Live position': '現在の局面',
  'Continue from here': 'ここから続ける', 'Edit position': '局面を編集', 'Position editor': '局面エディター', 'Set the board': '盤面を設定',
  'Choose a piece, then a square. Each missing rook, bishop, or knight goes to its owner’s reserve.': '駒を選んでからマスを選択します。盤上にないルーク、ビショップ、ナイトは持ち駒になります。',
  'Pieces': '駒', 'Erase': '消す', 'Side to move': '手番', 'Clear board': '盤面をクリア', 'Start here': 'ここから開始',
  'AI archive': 'AIアーカイブ', 'Sort': '並び替え', 'As recorded': '記録順', 'Shortest first': '短い順', 'Longest first': '長い順', 'Most repeated': '重複が多い順', 'Game library': '棋譜ライブラリ', 'Loading games…': '棋譜を読み込み中…', 'Library statistics': 'ライブラリ統計',
  'Filter games': '棋譜を絞り込む', 'Any AI': 'すべてのAI', 'Result': '結果', 'Any result': 'すべての結果', 'White won': '白の勝ち', 'Black won': '黒の勝ち',
  'Threefold draw': '同一局面3回による引き分け', 'Ply-limit draw': '手数上限による引き分け', 'Stalemate': 'ステイルメイト', 'Any version': 'すべてのバージョン',
  'Show more': 'もっと見る', 'Recorded game': '記録された対局', 'Game': '対局', 'Start': '最初へ', 'Auto · 1s': '自動・1秒', 'Play from here': 'ここから対戦',
  'Move transcript': '棋譜', 'Experiment provenance': '実験データ', 'Tactics': 'タクティクス', 'Find the checkmate': 'チェックメイトを見つけよう',
  'Puzzle mix': '問題の組み合わせ', 'Include': '出題する問題', 'Mate 1': '1手詰め', 'Mate 2': '2手詰め', 'Mate 3': '3手詰め', 'Mate 4': '4手詰め',
  'Hide mate depth': '詰み手数を隠す', 'Auto-next when solved': '正解後に自動で次へ', 'Loading verified puzzles…': '検証済みパズルを読み込み中…',
  'Find the forced checkmate.': '必至のチェックメイトを見つけてください。', 'Solution': '答え', 'Played line': '進行', 'Source positions': '出典局面',
  'Copied': 'コピーしました', 'Copy failed': 'コピーできませんでした', 'Select link': 'リンクを選択', 'Unavailable while offline': 'オフラインでは利用できません',
  'Pause': '一時停止', 'Resume AIs': 'AIを再開', 'Starting position': '開始局面', 'Ask to undo': '待ったをお願い', 'Review moves': '棋譜を見る', 'See that move': 'その手を見る',
  'Message your opponent…': '相手にメッセージ…', 'Voice connected.': '音声がつながりました。', 'Audio is on.': '音声はオンです。', 'Audio is off.': '音声はオフです。',
  'Video is on.': 'ビデオはオンです。', 'Video is off.': 'ビデオはオフです。', 'Requesting microphone access…': 'マイクへのアクセスを確認中…', 'Requesting camera access…': 'カメラへのアクセスを確認中…',
  'Tap “Hear audio” to listen.': '「相手の音声を聞く」を押してください。',
  'Opponent left': '相手が退出しました', 'The board is yours. Start a new game when you are ready.': '盤面はそのままです。準備ができたら新しい対局を始めてください。',
  'Draw': '引き分け', 'You and your opponent agreed to a draw.': '両者の合意で引き分けになりました。', 'Checkmate': 'チェックメイト', 'CHECK': '王手', 'CHECKMATE': '詰み',
  'You win.': 'あなたの勝ちです。', 'Your opponent wins.': '相手の勝ちです。', 'Stalemate — no legal move, and no check.': 'ステイルメイトです。合法手がなく、チェックもされていません。',
  'The same position came up three times.': '同じ局面が3回現れました。', 'Bot is placing its king': 'ボットがキングを配置中', 'Bot is thinking': 'ボットが考えています',
  'It is choosing from the same moves and deployments you have.': 'あなたと同じ移動と配置の選択肢から考えています。', 'Opponent’s turn': '相手の手番', 'Waiting for their move.': '相手の一手を待っています。',
  'Place your king': 'キングを配置してください', 'Pick any marked square on your home row. White places first, then Black.': '自陣一段目の印があるマスを選んでください。白、黒の順に配置します。',
  'Draw agreed': '引き分け成立', 'Threefold repetition': '同一局面3回', 'The same position came up three times, so the game is drawn.': '同じ局面が3回現れたため、引き分けです。',
  'You win': 'あなたの勝ち', 'Stalemate': 'ステイルメイト', 'Your seat': 'あなた', 'Defense': '守る側',
  'Choose at least one puzzle type': '問題を1種類以上選んでください', 'At least one mate depth must stay selected.': '詰み手数を1つ以上選択してください。',
  'That does not force checkmate. Try another move.': 'その手では必ずチェックメイトできません。別の手を試してください。',
  'Correct. The opponent replies…': '正解です。相手が応手します…', 'The defense moved. Keep calculating.': '相手が応手しました。読みを続けてください。',
  'Solution shown. Try the next puzzle when ready.': '答えを表示しました。準備ができたら次の問題へ。', 'Keep at least one mate depth selected.': '詰み手数を1つ以上選択してください。',
  'Place your king on the highlighted row.': '光っている段にキングを配置してください。', 'Your turn — tap or drag a piece.': 'あなたの手番です。駒をタップまたはドラッグしてください。',
  'Legal move. The machine is replying…': '合法手です。マシンが応手します…', 'The machine moved. Your turn.': 'マシンが指しました。あなたの手番です。',
  'Puzzles are still being generated': 'パズルを準備中です', 'Start of the game': '対局開始',
  'Game stopped': '対局を停止しました', 'Bot error': 'ボットエラー', 'The bot hit an error. Start a new game to try again.': 'ボットでエラーが発生しました。新しい対局でやり直してください。',
  '← Home': '← ホーム', 'Black reserve': '黒の持ち駒', 'White reserve': '白の持ち駒', 'Your reserve': 'あなたの持ち駒',
  'Listening for a second player': '対戦相手を待っています', 'No relay is answering, so the link cannot reach anyone yet. It will connect on its own if the network comes back.': '中継サーバーから応答がなく、現在リンクを届けられません。ネットワークが戻ると自動で接続します。',
  'Still nobody. The link is live and the network is fine, so either they haven’t opened it yet — or they have, and the two networks can’t reach each other directly. Some mobile and office networks block that. Trying another network usually fixes it.': 'まだ相手がいません。リンクと通信は正常です。相手がまだ開いていないか、両者のネットワーク間で直接接続できない可能性があります。モバイル回線や社内ネットワークでは遮断される場合があるため、別の回線をお試しください。',
  'The invite was already used or has gone stale. Start a fresh one, or play the bot while you wait.': '招待リンクは使用済みか期限切れです。新しい対局を作るか、ボットと対戦してください。',
  'Opponent': '対戦相手', 'Bot · Black': 'ボット・黒', 'No moves yet': 'まだ棋譜はありません', '↑ / ↓ to review': '↑ / ↓ で棋譜を確認', '@ marks a deployment from reserve': '@ は持ち駒の配置',
  'Move the cursor one square. It wraps at the edges.': 'カーソルを1マス動かします。端では反対側へ移動します。', 'Enter': 'Enter', 'Pick up the piece under the cursor, or play the move.': 'カーソル上の駒を選ぶ、または着手します。',
  'Esc': 'Esc', 'Put the piece back down.': '選択中の駒を戻します。', 'Pick a reserve piece, then Enter on an empty square to deploy it.': '持ち駒を選び、空きマスでEnterを押して配置します。',
  'a – d then 1 – 4': 'a〜d、続けて1〜4', 'Type a square name to go straight there.': 'マス名を入力すると直接移動します。', 'Show this list.': 'この一覧を表示します。',
  'Arrow keys move the cursor, Enter picks up or plays, Escape puts the piece back down, 1 to 3 pick a reserve piece, a square name jumps there, and question mark lists the shortcuts.': '矢印キーでカーソルを移動、Enterで選択・着手、Escapeで選択解除。1〜3で持ち駒を選び、マス名で直接移動、?でショートカット一覧を表示します。',
  'unique games': '固有の棋譜', 'original records': '元の対局数', 'decisive': '勝敗あり', 'average plies': '平均プライ',
  'Bot': 'ボット', 'Online player': 'オンラインプレイヤー', 'Audio': '音声', 'Video': 'ビデオ',
  'Your browser is still blocking incoming audio.': 'ブラウザが相手の音声の再生をブロックしています。',
  'Offline · moves will send when you’re back': 'オフライン・再接続後に着手を送信します',
  'Your connection is unstable': '接続が不安定です', 'Retrying': '再試行中', 'You are back online.': 'オンラインに戻りました。',
  'You are offline. Moves will send when you are back.': 'オフラインです。再接続後に着手を送信します。',
  'Your opponent lost connection.': '相手との接続が切れました。', 'Not connected to the matchmaking network': 'マッチング用ネットワークに接続できません',
  'Microphone permission was not granted.': 'マイクの使用が許可されませんでした。', 'Could not start the microphone.': 'マイクを開始できませんでした。',
  'Camera permission was not granted.': 'カメラの使用が許可されませんでした。', 'Could not start the camera.': 'カメラを開始できませんでした。',
  'You asked to take back your move': '待ったをお願いしました', 'You offered a draw': '引き分けを提案しました',
  'The match is a draw by agreement.': '両者の合意で引き分けになりました。', 'Accept': '承諾', 'Decline': '辞退', 'Allow': '許可',
  'Invite for a rematch': '再戦に招待', 'Play again': 'もう一度対局', 'Rematch': '再戦',
  'The demo ended in a draw.': 'デモは引き分けになりました。',
  'Place your king on one of the highlighted home-row squares.': '光っている自陣のマスにキングを配置してください。',
  'Move your rook to one of the highlighted squares.': 'ルークを光っているマスのいずれかへ動かしてください。',
  'Deploy your bishop from the reserve to the highlighted square.': '持ち駒のビショップを光っているマスへ配置してください。',
}));

const PATTERNS = [
  [/^Rule (\d+) of (\d+)$/, (_, step, total) => `ルール ${step} / ${total}`],
  [/^Danger: (White|Black) can force mate in (\d+) despite every defense\.$/, (_, side, n) => `危険：どの応手でも${side === 'White' ? '白' : '黒'}が${n}手で詰ませられます。`],
  [/^(White|Black) can force mate in (\d+)\.$/, (_, side, n) => `${side === 'White' ? '白' : '黒'}が${n}手で詰ませられます。`],
  [/^Caution: (\d+) moves? allow an opponent mate in (\d+): (.*)\.$/, (_, count, depth, actions) => `注意：${count}手は相手の${depth}手詰めを許します：${actions}。`],
  [/^(White|Black|Even) advantage · ([\d.]+) \(estimate\)$/, (_, side, score) => `${side === 'Even' ? '互角' : `${side === 'White' ? '白' : '黒'}優勢`} · ${score}（推定）`],
  [/^Mate search incomplete beyond (\d+) moves? \(time limit\)\.$/, (_, n) => `${n}手を超える詰み解析は時間切れで未完了です。`],
  [/^(\d+) puzzles left in this shuffle$/, '$1問残っています'],
  [/^(White|Black) to move · mate in (\d+)$/, (_, side, n) => `${side === 'White' ? '白' : '黒'}の手番・${n}手詰め`],
  [/^(White|Black) to move · find the fastest mate$/, (_, side) => `${side === 'White' ? '白' : '黒'}の手番・最短の詰みを探してください`],
  [/^(Your|Their) reserve · (\d+)$/, (_, who, n) => `${who === 'Your' ? 'あなた' : '相手'}の持ち駒・${n}`],
  [/^(White|Black) reserve · (\d+)$/, (_, side, n) => `${side === 'White' ? '白' : '黒'}の持ち駒・${n}`],
  [/^([\d,]+) unique games?$/, '$1局'], [/^([\d,]+) plies · ([\d,]+) moves/, '$1プライ・$2手'],
  [/^([\d,]+) repeated records collapsed by exact move sequence\.$/, '同一の手順だった$1件の記録をまとめています。'],
  [/^Game #(\d+)$/, '対局 #$1'], [/^Ply (\d+) of (\d+) · (.*)$/, '$2手中 $1手目・$3'],
  [/^Game #(\d+), after ply (\d+)$/, '対局 #$1・$2プライ後'],
  [/^Checkmate — mate in (\d+) solved\.( Next puzzle coming…)?$/, (_, n, next) => `チェックメイト。${n}手詰め正解です。${next ? ' 次の問題へ進みます…' : ''}`],
  [/^The defense moved\. Continue the mate in (\d+)\.$/, '相手が応手しました。$1手詰めを続けてください。'],
  [/^Reviewing · before the first move$/, '確認中・初手前'], [/^Reviewing · move (\d+) of (\d+)$/, '$2手中 $1手目を確認中'],
  [/^The match ended on move (\d+)\. You can still walk back through it\.$/, '対局は$1手目で終了しました。棋譜をさかのぼって確認できます。'],
  [/^(.*) ran out of time$/, '$1の時間切れ'], [/^(.*) resigned$/, '$1が投了しました'],
  [/^(White|Black) wins by checkmate$/, (_, side) => `${side === 'White' ? '白' : '黒'}のチェックメイト勝ち`],
  [/^Draw by threefold repetition$/, '同一局面3回による引き分け'], [/^Draw by stalemate$/, 'ステイルメイトによる引き分け'],
  [/^(White|Black) · (.*)$/, (_, side, name) => `${side === 'White' ? '白' : '黒'}・${translateText(name, 'ja')}`],
  [/^(White|Black) reserve · tap to deploy$/, (_, side) => `${side === 'White' ? '白' : '黒'}の持ち駒・タップして配置`],
  [/^Your reserve · tap to deploy$/, 'あなたの持ち駒・タップして配置'], [/^Your reserve · empty$/, 'あなたの持ち駒・なし'],
  [/^Last: (.*)$/, '直前：$1'], [/^(Audio|Video) (on|off)$/, (_, media, state) => `${media === 'Audio' ? '音声' : 'ビデオ'}${state === 'on' ? 'オン' : 'オフ'}`],
  [/^Reviewing ply (\d+) of (\d+)$/, '$2手中 $1手目を確認中'],
  [/^(White|Black): place your king on the home row$/, (_, side) => `${side === 'White' ? '白' : '黒'}：自陣の一段目にキングを置いてください`],
  [/^(White|Black) to move · (.*)$/, (_, side, seat) => `${side === 'White' ? '白' : '黒'}の手番・${translateText(seat)}`],
  [/^(White|Black) (.*) is thinking…$/, (_, side, bot) => `${side === 'White' ? '白' : '黒'}の${translateText(bot)}が考えています…`],
  [/^Paused before (White|Black) moves$/, (_, side) => `${side === 'White' ? '白' : '黒'}の手番前で一時停止`],
  [/^(\d+):(\d{2}) left$/, '$1:$2 残り'],
  [/^(King|Rook|Bishop|Knight) on ([a-d][1-4]) is selected\. (.*)$/, (_, piece, square, rest) => `${pieceJa(piece)}（${square}）を選択中。${translateText(rest, 'ja')}`],
  [/^Your king is in check(?: from .*?)?\. Move, capture, or deploy a reserve piece to block it\.$/, 'キングがチェックされています。移動、駒を取る、または持ち駒を配置して防いでください。'],
  [/^Empty (rook|bishop|knight) reserve slot$/, (_, piece) => `空の${pieceJa(piece)}持ち駒枠`],
  [/^(white|black) (rook|bishop|knight) in reserve$/, (_, side, piece) => `${side === 'white' ? '白' : '黒'}の持ち駒の${pieceJa(piece)}`],
  [/^(\d+) matching records$/, '$1件の棋譜'], [/^Run (\d+) · (\d+) source records$/, '実験$1・元データ$2局'],
  [/^Your king ran out of squares(?: on [a-d][1-4])?\..*$/, 'キングの逃げ場がなくなりました。棋譜を戻って防ぎ方を確認できます。'],
  [/^(White|Black) has no legal move and is not in check\..*$/, '合法手がなく、チェックもされていないためステイルメイトです。'],
  [/^Neither side pressed on.*$/, 'どちらも勝ち切れず、手数上限で引き分けになりました。'],
  [/^(White|Black) deployed a (king|rook|bishop|knight) on ([a-d][1-4])$/, (_, side, piece, square) => `${side === 'White' ? '白' : '黒'}が${pieceJa(piece)}を${square}に配置`],
  [/^(White|Black) moved a (king|rook|bishop|knight) from ([a-d][1-4]) to ([a-d][1-4])$/, (_, side, piece, from, to) => `${side === 'White' ? '白' : '黒'}の${pieceJa(piece)}が${from}から${to}へ移動`],
  [/^(White|Black) captured a (king|rook|bishop|knight) on ([a-d][1-4]) with a (king|rook|bishop|knight) from ([a-d][1-4])$/, (_, side, captured, to, piece, from) => `${side === 'White' ? '白' : '黒'}の${pieceJa(piece)}が${from}から${to}へ進み${pieceJa(captured)}を取る`],
];

function pieceJa(piece) {
  return ({ king: 'キング', rook: 'ルーク', bishop: 'ビショップ', knight: 'ナイト' })[String(piece).toLowerCase()] ?? piece;
}

export function language(storage = localStorage, navigatorLanguage = navigator.language) {
  try { const saved = storage.getItem(STORAGE_KEY); if (SUPPORTED.has(saved)) return saved; } catch {}
  return String(navigatorLanguage).toLowerCase().startsWith('ja') ? 'ja' : 'en';
}

export function translateText(text, locale = language()) {
  if (locale !== 'ja' || !text) return text;
  if (JA.has(text)) return JA.get(text);
  for (const [pattern, replacement] of PATTERNS) if (pattern.test(text)) return text.replace(pattern, replacement);
  return text;
}

export function initI18n() {
  const locale = language();
  document.documentElement.lang = locale;
  translateTree(document, locale);
  // Prefer the action group explicitly. A selector list containing `header`
  // returns the ancestor first in document order, even when `.header-actions`
  // appears first in the selector text. Inserting before a nested theme button
  // on that ancestor throws and prevents the rest of the page from starting.
  const header = document.querySelector('header .header-actions')
    ?? document.querySelector('header nav')
    ?? document.querySelector('header');
  if (header && !document.querySelector('[data-language-toggle]')) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'text-button language-button btn';
    button.dataset.variant = 'ghost';
    button.dataset.languageToggle = '';
    // 日本 is "Japan". This is the first Japanese a Japanese speaker reads here.
    button.textContent = locale === 'ja' ? 'EN' : '日本語';
    button.setAttribute('aria-label', locale === 'ja' ? '英語に切り替える' : 'Switch to Japanese');
    // Last in the row, after the hairline: the language is a different kind of
    // decision from the two page controls, and the order is the same on all
    // five pages — brand, page controls, rule, language.
    header.append(button);
    button.addEventListener('click', () => {
      try { localStorage.setItem(STORAGE_KEY, locale === 'ja' ? 'en' : 'ja'); } catch {}
      location.reload();
    });
  }
  if (locale === 'ja') new MutationObserver((records) => {
    for (const record of records) {
      if (record.type === 'characterData') translateNode(record.target, locale);
      if (record.type === 'attributes') {
        const value = record.target.getAttribute(record.attributeName);
        const translated = translateText(value, locale);
        if (value && translated !== value) record.target.setAttribute(record.attributeName, translated);
      }
      for (const node of record.addedNodes) translateTree(node, locale);
    }
  }).observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true,
    attributeFilter: ['aria-label', 'placeholder', 'title', 'data-label', 'data-empty'] });
  return locale;
}

function translateTree(root, locale) {
  if (root.nodeType === Node.TEXT_NODE) return translateNode(root, locale);
  if (root.nodeType !== Node.ELEMENT_NODE && root.nodeType !== Node.DOCUMENT_NODE) return;
  if (root.nodeType === Node.ELEMENT_NODE) for (const attr of ['aria-label', 'placeholder', 'title', 'data-label', 'data-empty']) {
    const value = root.getAttribute(attr); const translated = translateText(value, locale);
    if (value && translated !== value) root.setAttribute(attr, translated);
  }
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
  let node; while ((node = walker.nextNode())) {
    if (node.nodeType === Node.TEXT_NODE) translateNode(node, locale);
    else for (const attr of ['aria-label', 'placeholder', 'title', 'data-label', 'data-empty']) {
      const value = node.getAttribute(attr); const translated = translateText(value, locale);
      if (value && translated !== value) node.setAttribute(attr, translated);
    }
  }
}

function translateNode(node, locale) {
  if (node.parentElement?.matches('script,style')) return;
  const raw = node.nodeValue; const trimmed = raw.trim(); if (!trimmed) return;
  const normalized = trimmed.replace(/\s+/g, ' ');
  const translated = translateText(normalized, locale);
  if (translated !== normalized) node.nodeValue = `${raw.match(/^\s*/)[0]}${translated}${raw.match(/\s*$/)[0]}`;
}
