import {writeFileSync,appendFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
import {analyzeAction as candidate} from './src/bot.js';
import {applyAction,createInitialPosition} from './src/rules.js';
import {seededRandom} from './src/tournament.js';
const {analyzeAction:control}=await import(pathToFileURL(resolve('src/bot.js')));
const out=new URL('./rows.jsonl',import.meta.url);
const starts=[];
for(const color of ['white','black'])for(let i=0;i<16;i++){
 let p=createInitialPosition({allowCheckingDrops:false,experiment:'capture-bank',bankCapacity:6});
 p=applyAction(p,{type:'place-king',to:12+i%4});
 p=applyAction(p,{type:'place-king',to:Math.floor(i/4)});
 // Color is the scheduled engine seat, as in the shared match generator.
 starts.push({color,i,p});
}
writeFileSync(new URL('./starts.json',import.meta.url),JSON.stringify(starts));
for(const fixed of [true,false])for(const [pass,on] of [true,false,false,true].entries())for(const {p,color,i} of starts){
 const saved=JSON.stringify(p),options={profile:'competitive',depth:fixed?5:20,quiescenceDepth:4,quiescenceEvasionDepth:2,quiescenceChecks:true,lateMoveReduction:!fixed,reduceQuietDrops:false,cacheEvaluation:true,cacheQuiescence:false,reducePrincipalVariation:true,cutoffReply:on,random:seededRandom(20262002),maxMillis:fixed?1000:100,...(fixed?{maxNodes:100000}:{})};
 const t=performance.now(),result=(on?candidate:control)(p,options),ms=performance.now()-t;
 assert.equal(JSON.stringify(p),saved);
 let replay=p;for(const action of result.pv)replay=applyAction(replay,action);
 appendFileSync(out,JSON.stringify({fixed,pass,on,color,i,ms,result})+'\n');
}
