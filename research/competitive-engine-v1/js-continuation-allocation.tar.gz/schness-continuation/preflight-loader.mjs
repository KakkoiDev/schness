import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const target=pathToFileURL(resolve('src/search.js')).href;
export async function load(url,context,next){
 if(url!==target)return next(url,context);
 const source=(await readFile(new URL('./src/search.js',import.meta.url),'utf8'));
 return {format:'module',source,shortCircuit:true};
}
