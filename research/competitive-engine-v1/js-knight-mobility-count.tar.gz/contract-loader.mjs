export async function resolve(specifier,context,next){
 if(specifier==='../src/bot.js' && /\/(engine-contract-js|search-tactics.test|broad-tactical-mates.test)\.js$/.test(context.parentURL??'')){
   return next(new URL('./candidate/bot.js',import.meta.url).href,context);
 }
 return next(specifier,context);
}
