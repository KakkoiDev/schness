export * from '../candidate/bot.js';
import {analyzeAction as search} from '../candidate/bot.js';
export const analyzeAction=(p,o)=>search(p,{...o,cachePositionalSubtotal:true});
