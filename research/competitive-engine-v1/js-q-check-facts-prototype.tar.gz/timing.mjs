import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {analyzeAction as a} from './baseline/bot.js';
import {analyzeAction as b} from './candidate/bot.js';
import * as rules from './baseline/rules.js';
const cases=JSON.parse(readFileSync(new URL('./inputs.json',import.meta.url))).cases;
assert.equal(cases.length,32);
const shared={profile:'competitive',iterativeDeepening:true,quiescenceDepth:4,quiescenceChecks:true,quiescenceEvasionDepth:2,cacheEvaluation:true,cacheQuiescence:false,reducePrincipalVariation:true,reduceQuietDrops:false};
const settings={fixed:{...shared,depth:4,lateMoveReduction:false,maxNodes:100000,maxMillis:200,stopOnProvenWin:false},timed:{...shared,depth:20,lateMoveReduction:true,maxMillis:100}};
const results={};
for(const [name,options] of Object.entries(settings)){
 const rows=[];
 for(const arm of ['a','b','b','a']){
  const search=arm==='a'?a:b;
  const pass=[];
  for(const {id,position:p,result:terminal} of cases){
   const snapshot=JSON.stringify(p);
   const t=performance.now();
   const result=search(p,{...options,reuseQCheckFact:arm==='b'});
   const elapsed=performance.now()-t;
   assert.equal(JSON.stringify(p),snapshot);
   if(terminal)assert.equal(result.action,null);
   else{
    rules.applyAction(p,result.action);
    if(result.pv.length)assert.deepEqual(result.pv[0],result.action);
    let q=p;for(const action of result.pv)q=rules.applyAction(q,action);
   }
   pass.push({id,elapsed,result});
  }
  rows.push({arm,pass});
 }
 results[name]={options,rows};
}
const counters=[];
for(const {id,position:p} of cases){
 let reused=0;
 const result=b(p,{...settings.fixed,reuseQCheckFact:true,onQCheckReuse:()=>reused++});
 counters.push({id,reused,depth:result.completedDepth,stats:result.stats});
}
const complete=[], discrepancies=[];
for(let i=0;i<32;i++){
 const roots=results.fixed.rows.map(x=>x.pass[i]);
 if(!cases[i].result && roots.some(x=>x.result.completedDepth!==4||x.result.stopped))continue;
 complete.push(i);
 for(const key of ['action','score','nodes','pv','completedDepth','variations'])if(!roots.every(x=>JSON.stringify(x.result[key])===JSON.stringify(roots[0].result[key])))discrepancies.push({i,key});
}
function sums(name,arm,ids,key){
 return results[name].rows.filter(x=>x.arm===arm).flatMap(x=>ids.map(i=>x.pass[i])).reduce((n,x)=>n+(key==='elapsed'?x.elapsed:x.result.completedDepth),0);
}
const fixedMs=['a','b'].map(x=>sums('fixed',x,complete,'elapsed'));
const depth=['a','b'].map(x=>sums('timed',x,cases.map((_,i)=>i),'depth')/64);
const timedMs=['a','b'].map(x=>sums('timed',x,cases.map((_,i)=>i),'elapsed')/64);
const saving=1-fixedMs[1]/fixedMs[0];
const summary={complete,discrepancies,fixedMs,depth,timedMs,saving,pass:complete.length>=28&&!discrepancies.length&&saving>=0.05&&depth[1]>=depth[0]};
writeFileSync(new URL('./timing-results.json',import.meta.url),JSON.stringify({results,counters,summary},null,2));
console.log(JSON.stringify(summary));
