import assert from 'node:assert/strict';
import {contractRequests,assertContract} from './scripts/engine-contract.js';
import {executeContract} from './scripts/engine-contract-js.js';
import * as r from './candidate/rules.js';
import * as b from './baseline/rules.js';
import {analyzeAction as control} from './baseline/bot.js';
import {analyzeAction as candidate} from './candidate/bot.js';
let rules=0, calls=0, hits=0, contracts=0;
function verify(p,checked){
 assert.equal(checked,b.isInCheck(p,p.turn));
 calls++;hits+=Number(checked);
}
for (const request of contractRequests()){
  assertContract(request,executeContract({...request,options:{...request.options,reuseQCheckFact:true}}));contracts++;
  const {state:p,options,game}=request;
  if(game==='schness-rules-v1'){
    rules++;
    assert.deepEqual(r.legalActions(p),b.legalActions(p),request.id);
  }
  if(game==='schness-v1'||game==='schness-rules-v1'){
    const snapshot=JSON.stringify(p);
    for(const opts of [options??{profile:'competitive',depth:2,maxNodes:1000},{profile:'competitive',depth:4,maxNodes:64}]){
      const a=control(p,opts),c=candidate(p,{...opts,reuseQCheckFact:true,onQCheckReuse:verify});
      for(const key of ['action','score','completedDepth','nodes','stopped','pv','variations']) assert.deepEqual(c[key],a[key],request.id+': '+key);
      assert.equal(JSON.stringify(p),snapshot,request.id);
    }
  }
}
console.log(JSON.stringify({contracts,rules,calls,hits}));

const {readFileSync}=await import('node:fs');
const {cases}=JSON.parse(readFileSync(new URL('./inputs.json',import.meta.url)));
for (const {position:p} of cases) candidate(p,{profile:'competitive',depth:4,maxNodes:100000,maxMillis:200,quiescenceDepth:4,quiescenceChecks:true,quiescenceEvasionDepth:2,cacheEvaluation:true,lateMoveReduction:false,onQCheckReuse:verify,reuseQCheckFact:true});
console.log(JSON.stringify({calls,hits}));
assert(hits>0);
